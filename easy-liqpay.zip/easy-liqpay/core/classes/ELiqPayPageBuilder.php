<?php

class ELiqPayPageBuilder
{
    private $fields =[];
    private $user_capability = 'manage_options';
    private $current_section = '';
    private $eliqpal_option;
    private $subpages = [];
    private $fieldsController;
    private $menu_page_suffix = null;

    function __construct() {
        $this->eliqpal_option = elp_get_option();

        add_action( 'admin_menu', [ $this, '_registerAdminPages' ] );
        add_action( 'admin_init', [ $this, '_registerSettingsFields' ] );

        add_filter( 'pre_update_option', [ $this, 'handlerPreUpdateOptionFilter'], 10, 3 );

        require_once ELIQPAY_CLASSES_PATH .'/ELiqPayFeldsController.php';
        $this->fieldsController = new ELiqPayFeldsController();

        require_once ELIQPAY_CORE .'/load_fields.php';
    }

    // PRIVATE METHORD
    private function getAttr( $attr, $vars = [] ) {
        if ( empty( $vars ) ) {
            array_walk( $attr, function( &$val, $key ) { $val = "$key=\"$val\""; } );
            return implode(' ', $attr );
        }

        $vars_atts = [];

        foreach( $attr as $prop_name => $prop_value ) {
            if ( is_array( $prop_value ) ) {
                foreach( $prop_value as $var_name => $var_value ) {
                    if ( in_array( $var_name, $vars ) ) {
                        $vars_atts[ $var_name ][ $prop_name ] = $var_value;
                    }
                }
            } else {
                array_walk( $vars, function( $val ) use ( &$vars_atts, $prop_name, $prop_value ) {
                    if ( 'id' === strtolower( $prop_name ) ) {
                        $prop_value .= "_$val";
                    }

                    if ( !isset( $vars_atts[ $prop_name ] ) ) {
                        $vars_atts[ $val ][ $prop_name ] = $prop_value;
                    }
                } );
            }
        }

        array_walk( $vars_atts, function( &$val, $key ) {
            $temp_val = [];
            foreach( $val as $prop_name => $prop_val ) {
                $temp_val[] = "$prop_name=\"$prop_val\"";
            }
            $val = implode( ' ', $temp_val );
        });

        return $vars_atts;
    }

    private function getFieldName( $name ) {
        return ELIQPAY_OPTION_NAME ."[$name]";
    }

    /*
     * Check if user have permission for edit page
     */
    private function checkPermission() {
        if ( !current_user_can( $this->user_capability ) )  {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'eliqpay' ) );
        }

        return true;
    }

    //PUBLIC METHODS

    public function _registerAdminPages() {
        if ( empty( $this->subpages ) ) {
            return;
        }

        foreach( $this->subpages as $sp_slug => $sp ) {
            if ( is_null( $this->menu_page_suffix ) ) {
                $this->menu_page_suffix = add_menu_page(
                    __( 'LiqPay Setting', 'eliqpay' ),
                    __( 'LiqPay', 'eliqpay' ),
                    $this->user_capability,
                    'eliqpay_setup',
                    $sp['callback'],
                    plugins_url( ELIQPAY_NAME .'/img/menu-icon.png' ),
                    85
                );
            }

            add_submenu_page(
                'eliqpay_setup',
                $sp['title'],
                $sp['title'],
                $this->user_capability,
                $sp_slug,
                $sp['callback']
            );
        }
    }

    public function _registerSettingsFields() {
        foreach( $this->fields as $page_id => $page_fields ) {

            register_setting( $page_id, ELIQPAY_OPTION_NAME );

            foreach( $page_fields as $field_id => $field ) {
                if ( 'section' === $field['type'] ) {
                    add_settings_section(
                        $field_id,
                        $field['title'],
                        [ $this, '_printFormSection'],
                        $page_id
                    );
                } else {
                    add_settings_field(
                        $field_id,
                        $field['label'],
                        [ $this, '_callbackFormField' ],
                        $page_id,
                        $field['section'],
                        $field
                    );
                }
            }
        }
    }

    public function _printFormSection( $arg ) {
        //TODO: Add print description
        return;
    }

    public function _callbackFormField( $args ) {
        if ( !isset( $args['attr']['id'] ) ) {
            $args['attr']['id'] = $args['name'];
            if ( !empty( $args['section']  ) ) {
                $args['attr']['id'] = $args['section'] .'_'. $args['attr']['id'];
            }
        }

        if ( !empty( $args['required'] ) ) {
            $args['attr']['required'] = 'required';
        }


        if ( !empty( $args['attr'] ) )  {
            $vars = !empty( $args['values'] ) ? array_keys( $args['values'] ) : [];
            $args['attr'] = $this->getAttr( $args['attr'], $vars );
        }


        $value = $this->getValue( $args['name'] );

        if ( isset( $args['value'] ) ) {
            $value = is_null( $value ) ? $args['value'] : $value;
        }

        $callback_args = [
            $this->getFieldName( $args['name'] ),
            $value,
            [
                'prop' => $args,
                'callback_args' => !empty( $this->fieldsController->fields[$args['type']]['args'] ) ? $this->fieldsController->fields[$args['type']]['args'] : []
            ]
        ];
        
        call_user_func_array( $this->fieldsController->fields[$args['type']]['handler'], $callback_args );
    }

    public function getValue( $field_name ) {
        return isset( $this->eliqpal_option[ $field_name ] ) ? $this->eliqpal_option[ $field_name ] : null;
    }


    public function handlerPreUpdateOptionFilter( $value, $option, $old_value ) {
        // If no set option
        if( ELIQPAY_OPTION_NAME !== $option ) {
            return $value;
        }
        // If another page or no have fields in this page
        if ( empty( $this->fields[ $_POST['option_page'] ] )) {
            return $value;
        }

        foreach( $this->fields[ $_POST['option_page'] ] as $field_id => $field_data ) {
            if ( 'section' == $field_data['type']) {
                continue;
            }

            $opt_name = $field_data['name'];

            $opt_val = isset( $value[ $opt_name ] ) ? $value[ $opt_name ] : false;
            $value[ $opt_name ] = $opt_val;

            // If field type have sanitize function
            if ( !empty( $this->fieldsController->fields[ $field_data['type'] ]['sanitize'] ) ) {
                $opt_old_val = isset( $old_value[ $opt_name ] ) ? $old_value[ $opt_name ] : false;

                $value[ $opt_name ] = call_user_func_array( 
                    $this->fieldsController->fields[ $field_data['type'] ]['sanitize'], 
                    [ $opt_val, $opt_old_val, $field_data ]
                );
            }
        }
        
        return $value;
    }
    
    //Public API
    
    public function registerSubpage( $slug, $title, $callback ) {

        $this->current_section = $slug;
        $this->fields = array_merge( $this->fields, [ $slug => [] ] );

        $this->subpages[$slug] = [
            'title' => $title,
            'callback' => $callback
        ];

        return $this;
    }

    public function setPage( $page_slug ) {
        $this->current_section = $page_slug;

        return $this;
    }

    public function addFields( $fields ) {
        if ( empty( $this->current_section ) ) {
            // TODO: Warning: No set page
            return;
        }

        if ( !isset( $this->fields[ $this->current_section ] ) ) {
            $this->fields[ $this->current_section ] = [];
        }

        // TODO: During first init update option with default values

        foreach( $fields as $field ) {
            
            // Check register field type
            if ( 'section' !== $field['type'] && !array_key_exists( $field['type'], $this->fieldsController->fields) ) {
                //TODO: Warning: Field type not registered
                continue;
            }

            if ( !empty( $field['id'] ) ) {
                $field_id = $field['id'];
            } else {
                $field_id = $field['name'];

                if (!empty($field['section'])) {
                    $field_id = $field['section'] . '_' . $field_id;
                }
            }

            $this->fields[ $this->current_section ][ $field_id ] = $field;
        }
    }
}