<?php

class ELiqPayEmail
{
	
}