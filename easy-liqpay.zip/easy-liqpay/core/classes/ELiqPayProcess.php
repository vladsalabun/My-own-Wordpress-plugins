<?php

class ELiqPayProcess {
	private $liqpay_api;
	private $default_options;

	function __construct( $key_pub, $key_priv ) {
		require_once ELIQPAY_PLUGIN_PATH .'/SDK/LiqPay.php';

		$this->liqpay_api = new LiqPay($key_pub, $key_priv);
		$this->default_options = elp_get_option();

		add_action( 'wp_ajax_elp_process', [$this, 'api_process'] );
		add_action( 'wp_ajax_nopriv_elp_process', [$this, 'api_process'] );
	}

	public function api_process() {
		//TODO: Find solution for disable warnings & errors		
		
		$order_id = substr( base64_encode(rand(100,999) . rand(100,999) . rand(100,999) ), 0, 8 );

		$param = [
			'version' => '3',
			'public_key' => $this->default_options['public_key'],
			'action' => apply_filters('elp_process_action', 'paydonate'),
			'amount' => isset($_POST['amount']) ? $_POST['amount'] : $this->default_options['amount'],
			'currency' => isset($_POST['currency']) ? $_POST['currency'] : key( $this->default_options['currency'] ),
			'order_id' => $order_id,
			'language' => isset($_POST['language']) ? $_POST['language'] : $this->default_options['language'],
			'result_url' => isset($_POST['result_url']) ? $_POST['result_url'] :$this->default_options['result_url'],
			'description' => isset($_POST['description']) ? $_POST['description'] : $this->default_options['payment_description'],
			'server_url' => ELIQPAY_CALLBACK_API
		];
		if ( !empty( $this->default_options['sandbox'] ) ) {
			$param['sandbox'] = '1';
		}

		$lp_responce = [
			'signature' => $this->liqpay_api->cnb_signature( $param) ,
			'data' => base64_encode( json_encode( $param ) ),
		];

		echo json_encode( $lp_responce );

		wp_die();
	}
}

$private_key = elp_get_option('private_key');
$public_key = elp_get_option('public_key');

new ELiqPayProcess($public_key, $private_key);