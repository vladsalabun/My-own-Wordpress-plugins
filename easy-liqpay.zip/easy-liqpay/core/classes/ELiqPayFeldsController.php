<?php

class ELiqPayFeldsController
{
	public $fields = [];	
	private $current_field = '';

	public function __construct() {

	}

	// Private methods
	private function checkCurrentField() {
		return !empty( $this->current_field );
	}

	// Public API
	public function registerField( $name, $handler, $file_handler = null ) {
		if ( !is_null( $file_handler ) && file_exists( $file_handler ) ) {

			require_once $file_handler;
		}

		if ( isset( $this->fields[ $name ] ) ) {
			//TODO: Error, field is exixts
		}

		if ( function_exists( $handler ) ) {
			$this->current_field = $name;
			$this->fields[ $name ]['handler'] = $handler;

			return $this;
		} else {
			//TODO: Error, function not exists
		}
	}

	public function addArguments( $args = [] ) {
		if ( $this->checkCurrentField() ) {
			$this->fields[ $this->current_field ]['args'] = $args;
		}

		return $this;
	}

	public function addSanitize( $sanitize_callback = [] ) {
		if ( function_exists( $sanitize_callback ) ) {
			if ( $this->checkCurrentField() ) {
				$this->fields[ $this->current_field ]['sanitize'] = $sanitize_callback;
			}
		} else {
			//TODO: warning, not exists sanitize function
		}

		return $this;
	}
}