<?php
if ( ! $this instanceof ELiqPayPageBuilder ) {
    return;
}

$field_folder = dirname( __FILE__ ) . '/fields';

$this->fieldsController->registerField('text', 'elp_field_text_callback', $field_folder .'/text.php' );
$this->fieldsController->registerField('textarea', 'elp_field_textarea_callback', $field_folder .'/textarea.php' );
$this->fieldsController->registerField('select', 'elp_field_select_callback', $field_folder .'/select.php' );
$this->fieldsController->registerField('checkbox', 'elp_field_checkbox_callback', $field_folder .'/checkbox.php' );
$this->fieldsController->registerField('radio', 'elp_field_radio_callback', $field_folder .'/radio.php' );
$this->fieldsController->registerField('number', 'elp_field_number_callback', $field_folder .'/number.php' );