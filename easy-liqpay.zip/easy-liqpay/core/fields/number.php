<?php

function elp_field_number_callback( $name, $value, $args ) {
    $prop = $args['prop'];

    echo "<input type='number' name='$name' value='$value' {$prop['attr']} />";
}