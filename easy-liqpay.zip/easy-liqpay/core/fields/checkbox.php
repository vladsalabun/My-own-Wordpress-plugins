<?php

function elp_field_checkbox_callback( $name, $value, $args ) {
    $prop = $args['prop'];
    
    if ( !empty( $prop['values'] ) ) {
        foreach ($prop['values'] as $val => $label) {
            $checked = '';

            if ( !empty( $value[ $val ] )
                    || (
                        is_null( $value )
                        && ( 
                            !empty( $prop['checked'] ) 
                            && in_array( $val, $prop['checked'] )
                            )
                        )
                ) {

                $checked = 'checked="checked"';
            }
            $attr = $prop['attr'][$val];
            echo "<p><label><input type='checkbox' name='{$name}[$val]' value='1' $attr $checked /> $label</label></p>";
        }

        if ( !empty( $prop['required'] ) ) {
            echo "
            <script>
                jQuery(function(){
                    var requiredCheckboxes = jQuery('[name^=\"{$name}\"][required]');
                    if ( requiredCheckboxes.filter(':checked')) {
                        requiredCheckboxes.removeAttr('required');
                    }
                    requiredCheckboxes.change(function(){
                        if(requiredCheckboxes.is(':checked')) {
                            requiredCheckboxes.removeAttr('required');
                        } else {
                            requiredCheckboxes.attr('required', 'required');
                        }
                    });
                });
            </script>
            ";
        }
    } else {
        $checked = '';

        if ( ( !empty( $prop['checked'] ) && false === $value ) || '1' === $value )  {
            $checked = 'checked="checked"';
        }

        echo "<p><label><input type='checkbox' name='$name' value='1' {$prop['attr']} $checked /> {$prop['option_label']}</label></p>";
    }
}