<?php
function elp_field_radio_callback( $name, $value, $args ) {
    $prop = $args['prop'];

    foreach( $prop['values'] as $val => $label ) {
        $checked = checked( $val, $value, false );
        $attr = $prop['attr'][ $val ];
        echo "<p><label><input type='radio' name='$name' value='$val' $attr $checked /> $label</label></p>";
    }
}