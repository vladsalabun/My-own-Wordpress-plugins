<?php

function elp_field_text_callback( $name, $value, $args ) {
    $prop = $args['prop'];

    echo "<input type='text' name='$name' value='$value' {$prop['attr']} />";
}