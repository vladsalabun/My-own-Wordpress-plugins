<?php
function elp_field_textarea_callback( $name, $value, $args ) {
    $prop = $args['prop'];

    echo "<textarea name='$name' {$prop['attr']}>$value</textarea>";
}