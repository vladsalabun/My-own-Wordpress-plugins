<?php
require_once ELIQPAY_CLASSES_PATH .'/ELiqPayPageBuilder.php';

add_option( ELIQPAY_OPTION_NAME, $default_options, false, false );

$admin = new ELiqPayPageBuilder();

$admin->registerSubpage(
    'eliqpay_setup',
    __( 'LiqPay Setting', 'eliqpay' ),
    'elp_setup_page'
);/*->registerSubpage(
    'eliqpay_email_template',
    __( 'Email template', 'eliqpay' ),
    'elp_hello_world'
);
*/

/*
 * List of the setting fields
 */

$admin->setPage('eliqpay_setup')->addFields(
    [
        [
            'type' => 'section',
            'id' => 'main_setting',
            'title' => __('Main setting', 'eliqpay'),
            'description' => ''
        ],
        [
            'type' => 'text',
            'name' => 'private_key',
            'label' => __('Private key', 'eliqpay'),
            'section' => 'main_setting',
            'required' => true,
            'value' => '',
            'description' => '',
            'attr' => [
                'size' => '40'
            ]
        ],
        [
            'type' => 'text',
            'name' => 'public_key',
            'label' => __('Public key', 'eliqpay'),
            'section' => 'main_setting',
            'required' => true,
            'value' => '',
            'attr' => [
                'size' => '20'
            ],
            'description' => ''
        ],
        [
            'type' => 'section',
            'id' => 'required_setting',
            'title' => __('Required setting', 'eliqpay'),
            'description' => ''
        ],
        [
            'type' => 'textarea',
            'name' => 'payment_description',
            'label' => __( 'Payment description', 'eliqpay' ),
            'section' => 'required_setting',
            'required' => true,
            'value' => $default_options['payment_description'],
            'attr' => [
                'rows' => '5',
                'cols' => '60'
            ]
        ],
        [
            'type' => 'checkbox',
            'name' => 'currency',
            'label' => __('Currency', 'eliqpay' ),
            'section' => 'required_setting',
            'required' => true,
            'checked' => array_keys( $default_options['currency'] ),
            'values' => [
                'UAH' => __( 'UAH', 'eliqpay'  ),
                'RUB' => __( 'RUB', 'eliqpay'  ),
                'USD' => __( 'USD', 'eliqpay'  ),
                'EUR' => __( 'EUR', 'eliqpay'  )
            ]
        ],
        [
            'type' => 'section',
            'id' => 'optional_setting',
            'title' => __( 'Optional setting', 'eliqpay' ),
            'description' => ''
        ],
        [
            'type' => 'text',
            'name' => 'result_url',
            'label' => __( 'Result URL', 'eliqpay' ),
            'section' => 'optional_setting',
            'value' => $default_options['result_url'],
            'attr' => [
                'size' => '40'
            ]
        ],
        [
            'type' => 'number',
            'name' => 'default_amount',
            'label' => __( 'Default amount', 'eliqpay' ),
            'section' => 'optional_setting',
            'required' => true,
            'value' => $default_options['default_amount'],
            'description' => ''
        ],
        [
            'type' => 'radio',
            'name' => 'language',
            'label' => __( 'Language', 'eliqpay' ),
            'section' => 'optional_setting',
            'value' => $default_options['language'],
            'values' => [
                'ru' => __('Russian', 'eliqpay' ),
                'en' => __('English', 'eliqpay' )
            ],

        ],
        [
            'type' => 'checkbox',
            'name' => 'sandbox',
            'label' => __( 'Sandbox', 'eliqpay' ),
            'section' => 'optional_setting',
            'option_label' => __('Enable', 'eliqpay' )
        ]
    ]
);

function elp_setup_page() {
    require_once ELIQPAY_ADMIN_PATH . '/setting.php';
}

function elp_hello_world() {
    echo 'Hello world';
}

