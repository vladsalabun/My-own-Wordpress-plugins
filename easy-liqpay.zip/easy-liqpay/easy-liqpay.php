<?php
/*
Plugin Name: Easy LiqPay
Description: Wordpress LiqPay donation plugin
Version: 0.8.1
Author: Nick Antal
License: GPLv2 or later
Text Domain: eliqpay
Domain Path: /languages
*/

/*  Copyright 2016  Nick Antal  (email: nik.antal@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

define( 'ELIQPAY_VERSION', '0.8.1');
define( 'ELIQPAY_NAME', 'easy-liqpay');
define( 'ELIQPAY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'ELIQPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ELIQPAY_CORE', ELIQPAY_PLUGIN_PATH .'core' );
define( 'ELIQPAY_CLASSES_PATH', ELIQPAY_CORE . '/classes' );
define( 'ELIQPAY_ADMIN_PATH', ELIQPAY_PLUGIN_PATH . 'admin' );
define( 'ELIQPAY_PUBLIC_PATH', ELIQPAY_PLUGIN_PATH . 'public' );
define( 'ELIQPAY_WIDGETS_PATH', ELIQPAY_PUBLIC_PATH . '/widgets' );
define( 'ELIQPAY_CALLBACK_API', ELIQPAY_PLUGIN_URL .'elp-callback-api.php' );
define( 'ELIQPAY_OPTION_NAME', 'eliqpay_option' );

// Localization
add_action( 'plugins_loaded', 'eliqpay_load_textdomain' );
function eliqpay_load_textdomain() {
	load_plugin_textdomain( 'eliqpay', false, basename( dirname( __FILE__ ) ) . '/languages' );
}

//require_once ELIQPAY_PLUGIN_PATH .'/languages/l10n.php';

require_once ELIQPAY_PLUGIN_PATH .'/common.php';
require_once ELIQPAY_PUBLIC_PATH .'/utils.php';

add_action( 'init', function() {
	//die();
	
	if ( is_admin() ) {
		$default_options = [
			'private_key'	=> '',
			'public_key'	=> '',
			'payment_description' => __( 'Donation', 'eliqpay' ),
			'currency' => ['UAH' => '1'],
			'result_url' => get_bloginfo('url'),
			'default_amount' => '10',
			'language' => 'ru'
		];
		require_once ELIQPAY_ADMIN_PATH . '/admin.php';
	}
} );

require_once ELIQPAY_WIDGETS_PATH .'/widget-donat.php';

require_once ELIQPAY_CLASSES_PATH .'/ELiqPayProcess.php';