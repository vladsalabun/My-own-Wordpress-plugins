=== Easy LiqPay ===
Contributors: hermit931
Tags: liqpay, donta, privatbank, pb, privat24
Requires at least: 4.4
Tested up to: 4.4
Stable tag: 4.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adding a form for receive donations use the LiqPay

== Description ==

The plugin allows you add a form on the website to receive donations with a payment system LiqPay. The form can be added via the widget or shortcode [elp_donat]

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/easy-liqpay` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the LiqPay screen to configure the plugin
4. Use [elp_donat] shortcode or widget Donations for show form. Shortcode can accept parameter 'title' to set form title, and 'button_text' for button name

== Screenshots ==
1. Setting sceen
2. Result widget

== Changelog ==

= 0.8.1 =
Small fix

= 0.8.0 =
First public init