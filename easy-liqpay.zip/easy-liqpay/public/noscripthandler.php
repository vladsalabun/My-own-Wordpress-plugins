<form action='https://www.liqpay.com/api/checkout' method='POST' accept-charset="utf-8" name="elpform">
<?php
//TODO: Process incoming POST data, and sent to LiqPay Checkout
	foreach ($_POST as $a => $b) {
		echo "<input type='hidden' name='".htmlentities($a)."' value='".htmlentities($b)."'>";
	}
?>
</form>
<script language="JavaScript">
	document.elpform.submit();
</script>