(function($, document, undefined){
	"use strict";

	$(function(){
		if ( $('option', 'select.elp-input-currency').length == 1 ) {
			$('select.elp-input-currency').hide().after( function() {
				return '<div class="nice-select nice-single '+ $(this).attr('class') +'"><span class="current">'+ $('option:first', this).text() +'</span></div>';
			});
			//current
		} else {
			$('select.elp-input-currency').niceSelect();
		}
		
		var elpForm = $('form.elp-donat-form');

		
		elpForm.attr('action', 'https://www.liqpay.com/api/checkout' ).on('submit', function(e, submitForm) {
			if ( submitForm ) {
				return true;
			}
			
			e.preventDefault();

			var self = $(this),
				sendData = {
					action: 'elp_process',
					amount: $('[name="amount"]', self).val(),
					currency: $('[name="currency"]', self).val()
				};

			if ( $('[name="description"]', self).length > 0 ) {
				sendData['description'] = $('[name="description"]', self).val();
			}
			if ( $('[name="language"]', self).length > 0 ) {
				sendData['language'] = $('[name="language"]', self).val();
			}
			if ( $('[name="result_url"]', self).length > 0 ) {
				sendData['result_url'] = $('[name="result_url"]', self).val();
			}

			$.post(elp.ajaxurl, sendData, function( data ) {
				var data = $.parseJSON(data);

				for( var n in data ) {
					self.prepend('<input type="hidden" name="'+ n +'" value="'+ data[n] +'">');
				}

				self.trigger('submit', [true]);
			});

			return false;
		});
	});
}(jQuery, document));
/*  jQuery Nice Select - v1.0
    https://github.com/hernansartorio/jquery-nice-select
    Made by Hernán Sartorio  */
!function(e){e.fn.niceSelect=function(){this.hide(),this.each(function(){var s=e(this);if(!s.next().hasClass("nice-select")){s.after(e("<div></div>").addClass("nice-select").addClass(s.attr("class")||"").addClass(s.attr("disabled")?"disabled":"").attr("tabindex",s.attr("disabled")?null:"0").html('<span class="current"></span><ul class="list"></ul>'));var t=s.next(),n=s.find("option"),l=s.find("option:selected");t.find(".current").html(l.data("display")||l.text()),n.each(function(s){var n=e(this),l=n.data("display");t.find("ul").append(e("<li></li>").attr("data-value",n.val()).attr("data-display",l||null).addClass("option"+(n.is(":selected")?" selected":"")+(n.is(":disabled")?" disabled":"")).html(n.text()))})}}),e(document).off(".nice_select"),e(document).on("click.nice_select",".nice-select",function(s){var t=e(this);e(".nice-select").not(t).removeClass("open"),t.toggleClass("open"),t.hasClass("open")?(t.find(".option"),t.find(".focus").removeClass("focus"),t.find(".selected").addClass("focus")):t.focus()}),e(document).on("click.nice_select",function(s){0===e(s.target).closest(".nice-select").length&&e(".nice-select").removeClass("open").find(".option")}),e(document).on("click.nice_select",".nice-select .option:not(.disabled)",function(s){var t=e(this),n=t.closest(".nice-select");n.find(".selected").removeClass("selected"),t.addClass("selected");var l=t.data("display")||t.text();n.find(".current").text(l),n.prev("select").val(t.data("value")).trigger("change")}),e(document).on("keydown.nice_select",".nice-select",function(s){var t=e(this),n=e(t.find(".focus")||t.find(".list .option.selected"));if(32==s.keyCode||13==s.keyCode)return t.hasClass("open")?n.trigger("click"):t.trigger("click"),!1;if(40==s.keyCode){if(t.hasClass("open")){var l=n.nextAll(".option:not(.disabled)").first();l.length>0&&(t.find(".focus").removeClass("focus"),l.addClass("focus"))}else t.trigger("click");return!1}if(38==s.keyCode){if(t.hasClass("open")){var i=n.prevAll(".option:not(.disabled)").first();i.length>0&&(t.find(".focus").removeClass("focus"),i.addClass("focus"))}else t.trigger("click");return!1}if(27==s.keyCode)t.hasClass("open")&&t.trigger("click");else if(9==s.keyCode&&t.hasClass("open"))return!1});var s=document.createElement("a").style;s.cssText="pointer-events:auto","auto"!==s.pointerEvents&&e("html").addClass("no-csspointerevents")}}(jQuery);