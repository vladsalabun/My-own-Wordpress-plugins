<?php
// Out function
function elp_donat_template( $attr ) {	
	$options = elp_get_option();

	extract( wp_parse_args( $attr, [
		'button_text' => __( 'Donat!', 'eliqpay' ),
		'text_before' => '',
		'title' => '',
		'default_amount' => $options['default_amount'],
		'language' => $options['language'],
		'description' => $options['payment_description'],
		'result_page' => $options['result_url'],
		'currency' => $options['currency']
	] ) );

	elp_register_sources();

	$start_amound = !empty( $default_amount ) ? $default_amount : '';

	$template = '<div class="elp-conteiner">';
	if ( !empty( $title ) ) {
		$template .= '<div class="elp-title">'. $title .'</div>';
	}
	if ( !empty( $text_before ) ) {
		$template .= '<p class="elp-pre-text">'. $text_before .'</p>';
	}

		$template .= '<form class="elp-donat-form" method="POST" accept-charset="utf-8" action="'. ELIQPAY_PLUGIN_URL . 'public/noscripthandler.php' .'">';

		$template .= '<div class="elp-input-holder">';
		if ( !empty($language ) && $language !== $options['language'] ) {
			$template .= '<input type="hidden" name="language" value="'. $language .'" />';
		}
		if (!empty($description) && $description !== $options['payment_description'] ) {
			$template .= '<input type="hidden" name="description" value="'. $description .'" />';
		}
		if (!empty($result_page) && $result_page !== $options['result_url'] ) {
			$template .= '<input type="hidden" name="result_page" value="'. $result_page .'" />';
		}

		$template .= '<input type="text" name="amount" value="'. $start_amound .'" required />';
		$template .= '<select name="currency" class="elp-input-currency">';
		foreach ( array_keys( $currency ) as $cur_currency) {
			$template .= "<option value=\"$cur_currency\">$cur_currency</option>";
		}
		$template .= '</select>';
		$template .= '</div>';

		$template .= '<button class="elp-button">'. $button_text .'</button>';
		$template .= '</form>';
		
		$template .= apply_filters('elp_after_donat_form', '');

	$template .= '</div>';

	

	return $template;
}

function elp_donat_shortcode( $atts) {
	$atts = shortcode_atts( [
			'button_text' => '',
			'title' => ''
		],
		$atts,
		'elp_donat'
	);

	if ( '' == $atts['button_text'] ) {
		unset( $atts['button_text'] );
	}

	return elp_donat_template( $atts );
}

add_shortcode('elp_donat', 'elp_donat_shortcode');