<?php
class ELiqPayWidgetDonat extends WP_Widget {

	function __construct() {		
		$widget_ops = array( 
			'classname' => 'elp_widget_donat',
			'description' => __( 'Donat with LiqPay', 'eliqpay' ),
		);
		
		parent::__construct( 'elp_widget_donat', __( 'Donations', 'eliqpay' ), $widget_ops );
	}

	function widget( $args, $instance ) {

		echo $args['before_widget'];

		if ( !empty( $instance['currency'] ) ) {
			$instance['currency'] = array_combine( 
				array_values( $instance['currency'] ), 
				array_pad(
					[], 
					count($instance['currency']), 
					1
				)
			);
		} else {
			$instance['currency'] = elp_get_option('currency');
		}

		echo elp_donat_template( $instance );

		echo $args['after_widget'];
	}

	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = !empty( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['text_before'] = ! empty( $new_instance['text_before'] ) ? strip_tags( $new_instance['text_before'] ) : '';
		$instance['default_amount'] = !empty( $new_instance['default_amount'] ) ? $new_instance['default_amount']  : '';
		$instance['description'] = !empty( $new_instance['description'] ) ? strip_tags( $new_instance['description'] ) : '';
		$instance['currency'] = !empty( $new_instance['currency'] ) ? $new_instance['currency'] : array_keys( elp_get_option('curreny') );
		$instance['language'] = !empty( $new_instance['language'] ) ? $new_instance['language'] : '';
		$instance['result_url'] = !empty( $new_instance['result_url'] ) ? strip_tags( $new_instance['result_url'] ) : '';

		return $instance;
	}

	function form( $instance ) {
		$options = elp_get_option();

		$title = !empty( $instance['title'] ) ? $instance['title'] : __('Donation', 'eliqpay' ) ;
		$text_before = !empty( $instance['text_before'] ) ? $instance['text_before'] : '';
		$default_amount = isset( $instance['default_amount'] ) ? $instance['default_amount'] : '';
		$description = !empty( $instance['description'] ) ? $instance['description'] : $options['payment_description'];
		$currency = !empty( $instance['currency'] ) ? $instance['currency'] : array_keys( $options['currency'] );
		$language = !empty( $instance['language'] ) ? $instance['language'] : $options['language'];
		$result_url = !empty( $instance['result_url'] ) ? $instance['result_url'] : $options['result_url'];

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'eliqpay' ); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'text_before' ); ?>"><?php _e( 'Text before form', 'eliqpay' ); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'text_before' ); ?>" name="<?php echo $this->get_field_name( 'text_before' ); ?>" type="text" value="<?php echo esc_attr( $text_before ); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'default_amount' ); ?>"><?php _e( 'Default amount', 'eliqpay' ); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'default_amount' ); ?>" name="<?php echo $this->get_field_name( 'default_amount' ); ?>" type="text" value="<?php echo esc_attr( $default_amount ); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e( 'Payment description', 'eliqpay' ); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" type="text" value="<?php echo esc_attr( $description ); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'currency' ); ?>"><?php _e( 'Currency', 'eliqpay' ); ?>:</label>
			<?php
			$avaible_curreny = [
                'UAH' => __('UAH', 'eliqpay' ),
                'RUB' => __('RUB', 'eliqpay' ),
                'USD' => __('USD', 'eliqpay' ),
                'EUR' => __('EUR', 'eliqpay' )
			];
			foreach ($avaible_curreny as $key => $value) {
				$checked = in_array($key, $currency) ? 'checked="checked"' : '' ;
				echo "<br><label><input type=\"checkbox\" name=\"{$this->get_field_name( 'currency' )}[]\" value=\"$key\" $checked> $value</label>";
			}
			?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'language' ); ?>"><?php _e( 'Language', 'eliqpay' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'language' ); ?>" name="<?php echo $this->get_field_name( 'language' ); ?>">
			<?php
			$avaible_languages = [
                'ru' => __('Russian', 'eliqpay' ),
                'en' => __('English', 'eliqpay' )
			];
			foreach ($avaible_languages as $key => $value) {
				$selected = $key == $language ? ' selected="selected"' : '';
				echo "<option value=\"$key\"$selected>$value</option>";
			}
			?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'result_url' ); ?>"><?php _e( 'Result URL', 'eliqpay' ); ?>:</label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'result_url' ); ?>" name="<?php echo $this->get_field_name( 'result_url' ); ?>" type="text" value="<?php echo esc_attr( $result_url ); ?>">
		</p>
		<?php
	}
}

function elp_register_widgets() {
	register_widget( 'ELiqPayWidgetDonat' );
}

add_action( 'widgets_init', 'elp_register_widgets' );