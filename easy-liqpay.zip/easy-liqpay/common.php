<?php

function elp_register_sources() {
	if ( !wp_script_is( 'elq_scripts', 'registered' ) ) {
		wp_register_script( 'elq_scripts', plugins_url( 'public/assets/js/elp-scripts.js', __FILE__ ), ['jquery'], ELIQPAY_VERSION, true );
		
		$elp_data = [
			'ajaxurl' => admin_url('admin-ajax.php')
		];
		wp_localize_script( 'elq_scripts', 'elp', $elp_data );
	}

	if ( !wp_style_is( 'elq_styles', 'registered' ) ) {
		wp_register_style( 'elq_styles', plugins_url( 'public/assets/css/elp-common.css', __FILE__ ), [], ELIQPAY_VERSION );
	}
}

function elq_source() {
}

add_action('wp_enqueue_scripts', 'elq_source');

function elq_load_styles() {
	wp_enqueue_script( 'elq_scripts' );
	wp_enqueue_style('elq_styles');
}

add_action('wp_footer', 'elq_load_styles');

function elp_get_option( $opt_name = '' ) {
	$options = get_option( ELIQPAY_OPTION_NAME, [] );

	if ( !empty( $opt_name ) ) {
		return isset( $options[$opt_name] ) ? $options[$opt_name] : null;
	}

	return $options;
}