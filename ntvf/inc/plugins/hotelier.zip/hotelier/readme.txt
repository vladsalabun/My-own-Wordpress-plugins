=== WP Hotelier ===
Contributors: benitolopez, lollumthemes
Tags: hotel, booking, hostel, reservations, b&b, rooms, lollumthemes
Requires at least: 4.1
Tested up to: 4.5.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WP Hotelier is a powerful WordPress plugin allows you to manage Hotel, Hostel, B&B reservations with ease.

== Description ==

= Features =

* Accept instant payments (PayPal), manual payments or disable the online booking completely.
* Accept payments in full, or part at the time of booking.
* Manage rooms, beds, and prices.
* Seasonal prices.
* List your rooms by using shortcodes.
* Email notifications.

= Built with developers in mind =

Extendable and open source, WP Hotelier was created with developers in mind.

== Installation ==

= Minimum Requirements =

* WordPress 4.1 or greater
* PHP version 5.3.0 or greater
* Some payment gateways require fsockopen support (for IPN access)

== Frequently Asked Questions ==

= Will WP Hotelier work with my theme? =

Yes; WP Hotelier will work with any theme, but may require some styling to make it match nicely.

== Credits ==

This program incorporates work covered by WooCommerce (https://www.woothemes.com/woocommerce/). Thank you very much to all the WooThemes team for the permission.

And it includes some awesome JS libraries and plugins like:

- PhotoSwipe by Dmitry Semenov (http://photoswipe.com/)
- Fecha by Taylor Hakes (https://github.com/taylorhakes/fecha)

Thank you guys :)
