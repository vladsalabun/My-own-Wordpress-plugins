<?php
/**
 * The more button
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/content/room-more-button.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<a class="button view-room-details" href="<?php the_permalink() ?>"><?php esc_html_e( 'View Room Details', 'hotelier' ); ?></a>
