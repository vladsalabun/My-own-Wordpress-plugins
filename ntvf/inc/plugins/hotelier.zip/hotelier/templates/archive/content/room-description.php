<?php
/**
 * The room description
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/content/room-description.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post;

?>

<div class="room-description">
	<?php echo apply_filters( 'hotelier_short_description', $post->post_excerpt ) ?>
</div>
