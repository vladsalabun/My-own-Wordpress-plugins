<?php
/**
 * The room price
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/content/room-price.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<span class="price"><?php echo $room->get_min_price_html(); ?></span>
