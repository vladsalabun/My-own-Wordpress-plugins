<?php
/**
 * The Template for displaying rooms in a room category
 *
 * This template can be overridden by copying it to yourtheme/hotelier/archive/taxonomy-room_cat.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

htl_get_template( 'archive/archive-room.php' );
