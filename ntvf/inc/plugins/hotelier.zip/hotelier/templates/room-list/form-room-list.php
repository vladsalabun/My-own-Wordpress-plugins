<?php
/**
 * The Template for displaying rooms available on the given dates
 *
 * Override this template by copying it to yourtheme/hotelier/room-list/form-room-list.php
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

htl_print_notices();

// Check if we have valid dates before to run the query
if ( ! HTL_Formatting_Helper::is_valid_checkin_checkout( $checkin, $checkout ) ) : ?>

	<?php htl_get_template( 'room-list/no-rooms-available.php' ); ?>

<?php else :

	$room_ids_unavailable = htl_get_room_ids_unavailable( $checkin, $checkout );

	$query_args = array(
		'post_type'           => 'room',
		'post_status'         => 'publish',
		'order'               => 'ASC',
		'orderby'             => 'title',
		'ignore_sticky_posts' => 1,
		'posts_per_page'      => -1,
		'post__not_in'        => $room_ids_unavailable ? $room_ids_unavailable : array(),
		'meta_query'          => array(
			array(
				'key'     => '_stock_rooms',
				'value'   => 0,
				'type'    => 'numeric',
				'compare' => '>',
			),
		),
	);

	if ( isset( $_GET[ 'room_cat' ] ) ) {
		$room_cats = explode( ',', $_GET[ 'room_cat' ] );

		// Sanitize values
		$room_cats = array_map( 'absint', $room_cats );

		$query_args[ 'tax_query' ] = array(
			array(
				'taxonomy' => 'room_cat',
				'field'    => 'term_id',
				'terms'    => array_values( $room_cats )
			)
		);
	}

	if ( isset( $_GET[ 'room_rate' ] ) ) {
		$room_rates = explode( ',', $_GET[ 'room_rate' ] );

		// Sanitize values
		$room_rates = array_map( 'absint', $room_rates );

		$query_args[ 'tax_query' ][] = array(
			'taxonomy' => 'room_rate',
			'field'    => 'term_id',
			'terms'    => array_values( $room_rates )
		);
	}

	if ( isset( $_GET[ 'guests' ] ) ) {
		$guests = explode( ',', $_GET[ 'guests' ] );

		// Find higher value of 'guests' - We allow only one choice
		$guests = absint( max( $guests ) );

		$query_args[ 'meta_query' ][] = array(
			'key'     => '_max_guests',
			'value'   => $guests,
			'type'    => 'numeric',
			'compare' => '>=',
		);
	}

	if ( isset( $_GET[ 'children' ] ) ) {
		$children = explode( ',', $_GET[ 'children' ] );

		// Find higher value of 'children' - We allow only one choice
		$children = absint( max( $children ) );

		$query_args[ 'meta_query' ][] = array(
			'key'     => '_max_children',
			'value'   => $children,
			'type'    => 'numeric',
			'compare' => '>=',
		);
	}

	$rooms = new WP_Query( apply_filters( 'hotelier_shortcode_room_list_query', $query_args, $room_ids_unavailable ) );

	if ( $rooms->have_posts() && ( $room_ids_unavailable !== false ) ) : ?>

		<?php
			/**
			 * hotelier_room_list_datepicker hook
			 *
			 * @hooked hotelier_template_datepicker - 10
			 */
			do_action( 'hotelier_room_list_datepicker' );
		?>

		<?php
			/**
			 * hotelier_room_list_selected_nights hook
			 *
			 * @hooked hotelier_template_selected_nights - 10
			 */
			do_action( 'hotelier_room_list_selected_nights' );
		?>

		<form name="room_list" method="post" class="room-list" enctype="multipart/form-data">

			<?php do_action( 'hotelier_before_room_list_loop' ); ?>

			<?php hotelier_room_loop_start(); ?>

				<?php while ( $rooms->have_posts() ) : $rooms->the_post();

					global $room;

					// Ensure visibility
					if ( ! $room || ! $room->is_visible() ) {
						return;
					}
					?>

					<li <?php post_class(); ?>>

						<div class="room-content">

							<?php
								/**
								 * hotelier_room_list_item_title hook
								 *
								 * @hooked hotelier_template_rooms_left - 10
								 * @hooked hotelier_template_loop_room_title - 20
								 */
								do_action( 'hotelier_room_list_item_title' );
							?>

							<div class="room-gallery">

								<?php
									/**
									 * hotelier_room_list_item_thumb hook
									 *
									 * @hooked hotelier_template_loop_room_image - 10
									 * @hooked hotelier_template_loop_room_thumbnails - 20
									 */
									do_action( 'hotelier_room_list_item_images' );
								?>

							</div>

							<?php
								/**
								 * hotelier_room_list_item_content hook
								 *
								 * @hooked hotelier_template_loop_room_short_description - 10
								 */
								do_action( 'hotelier_room_list_item_content' );
							?>

							<div id="room-meta-<?php echo esc_attr( $room->id ); ?>" class="room-meta-wrap">

								<?php
									/**
									 * hotelier_room_list_item_meta hook
									 *
									 * @hooked hotelier_template_loop_room_facilities - 10
									 * @hooked hotelier_template_loop_room_meta - 15
									 * @hooked hotelier_template_loop_room_conditions - 20
									 */
									do_action( 'hotelier_room_list_item_meta' );
								?>

							</div>

							<?php
								/**
								 * hotelier_room_list_item_deposit hook
								 *
								 * @hooked hotelier_template_loop_room_deposit - 10
								 */
								do_action( 'hotelier_room_list_item_deposit' );
							?>

							<?php
								/**
								 * hotelier_room_list_item_guests hook
								 *
								 * @hooked hotelier_template_loop_room_guests - 10
								 */
								do_action( 'hotelier_room_list_item_guests' );
							?>

						</div><!-- .room-content -->

						<div class="room-actions">

						<?php
							/**
							 * hotelier_room_list_item_price hook
							 *
							 * @hooked hotelier_template_loop_room_price - 10
							 */
							do_action( 'hotelier_room_list_item_price' );
						?>

						<?php if ( $room->is_variable_room() ) : ?>

							<a href="#room-variations-<?php echo absint( $room->id ); ?>" data-closed="<?php esc_html_e( 'Show Rates', 'hotelier' ); ?>" data-open="<?php esc_html_e( 'Hide Rates', 'hotelier' ); ?>" class="button toggle-rates"><?php esc_html_e( 'Hide Rates', 'hotelier' ); ?></a>

							</div><!-- .room-actions -->

							<div class="clear"></div>

							<div id="room-variations-<?php echo absint( $room->id ); ?>" class="room-variations">

							<?php
							$varitations = $room->get_room_variations();

							// Print room rates
							foreach ( $varitations as $variation ) :
								$variation = new HTL_Room_Variation( $variation ); ?>

								<div class="room-single-variation">

								<?php hotelier_template_loop_room_variation( array( 'variation' => $variation ) ); ?>

								</div>

							<?php endforeach; ?>

							</div><!-- .room-variations -->

						<?php else : ?>

							<?php
								/**
								 * hotelier_room_list_item_add_to_cart hook
								 *
								 * @hooked hotelier_template_loop_room_add_to_cart - 10
								 */
								do_action( 'hotelier_room_list_item_add_to_cart' );
							?>

							</div><!-- .room-actions -->

						<?php endif; ?>

					</li>

				<?php endwhile; // end of the loop. ?>

			<?php hotelier_room_loop_end(); ?>

			<?php wp_reset_postdata(); ?>

			<?php
				/**
				 * hotelier_reserve_button hook
				 *
				 * @hooked hotelier_template_loop_room_reserve_button - 10
				 */
				do_action( 'hotelier_reserve_button' );
			?>

			<?php do_action( 'hotelier_after_room_list_loop' ); ?>

		</form>

	<?php else: ?>

		<?php htl_get_template( 'room-list/no-rooms-available.php' ); ?>

	<?php endif;

endif; ?>

<?php do_action( 'hotelier_after_room_list_form' ); ?>
