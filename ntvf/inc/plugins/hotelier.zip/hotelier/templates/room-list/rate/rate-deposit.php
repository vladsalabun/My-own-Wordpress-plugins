<?php
/**
 * Room rate desposit
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/rate/rate-deposit.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $variation->needs_deposit() ) : ?>

<div class="room-deposit">
	<span class="deposit-label"><?php esc_html_e( 'Deposit Required', 'hotelier' ); ?></span>
	<span class="deposit-amount"><?php echo esc_html( $variation->get_formatted_deposit() ); ?></span>
</div>

<?php endif; ?>
