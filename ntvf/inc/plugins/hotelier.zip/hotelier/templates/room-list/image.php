<?php
/**
 * Room thumbnail
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/image.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post, $room;

?>

<div class="room-image">

	<?php
		if ( has_post_thumbnail() ) {
			$image_title   = esc_attr( get_the_title( get_post_thumbnail_id() ) );
			$image_caption = get_post( get_post_thumbnail_id() )->post_excerpt;
			$image_large   = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
			$image_link    = esc_url( $image_large[ 0 ] );
			$image_width   = absint( $image_large[ 1 ] );
			$image_height  = absint( $image_large[ 2 ] );
			$image         = get_the_post_thumbnail( $post->ID, 'room_thumbnail', array(
				'title'	=> $image_title,
				'alt'	=> $image_title
				) );

			echo apply_filters( 'hotelier_room_list_image_html', sprintf( '<a href="%s" data-size="%sx%s" data-index="0" class="room-thumbnail" title="%s">%s</a>', $image_link, $image_width, $image_height, $image_caption, $image ), $post->ID );

		} else {

			echo '<a href="' . esc_url ( get_the_permalink() ) . '">' . htl_placeholder_img( 'room_thumbnail' ) . '</a>';

		}
	?>
</div>
