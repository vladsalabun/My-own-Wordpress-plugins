<?php
/**
 * Room price
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/price.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

$checkin  = HTL()->session->get( 'checkin' );
$checkout = HTL()->session->get( 'checkout' );

if ( $price_html = $room->get_price_html( $checkin, $checkout ) ) : ?>

	<div class="room-price">
		<span class="price"><?php echo $price_html; ?></span>
		<span class="price-description"><?php esc_html_e( 'Prices are per room', 'hotelier' ); ?></span>
	</div>

<?php endif; ?>
