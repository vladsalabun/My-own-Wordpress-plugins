<?php
/**
 * Room meta
 *
 * This template can be overridden by copying it to yourtheme/hotelier/room-list/meta.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<div class="room-meta">

	<?php if ( $room->get_room_size() ) : ?>
		<p class="room-size"><strong><?php esc_html_e( 'Room Size:', 'hotelier' ) ?></strong> <?php echo esc_html( $room->get_formatted_room_size() ); ?></p>
	<?php endif; ?>

	<?php if ( $room->get_bed_size() ) : ?>
		<p class="room-bed-size"><strong><?php esc_html_e( 'Bed Size(s):', 'hotelier' ) ?></strong> <?php echo esc_html( $room->get_bed_size() ); ?></p>
	<?php endif; ?>

</div>
