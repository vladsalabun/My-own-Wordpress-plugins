<?php
/**
 * Guest details
 *
 * This template can be overridden by copying it to yourtheme/hotelier/reservation/guest-details.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<header><h3><?php esc_html_e( 'Guest Details', 'hotelier' ); ?></h3></header>

<table class="guest-details hotelier-table">
	<?php if ( $reservation->get_formatted_guest_full_name() ) : ?>
		<tr>
			<th><?php esc_html_e( 'Name:', 'hotelier' ); ?></th>
			<td><?php echo esc_html( $reservation->get_formatted_guest_full_name() ); ?></td>
		</tr>
	<?php endif; ?>

	<?php if ( $reservation->guest_email ) : ?>
		<tr>
			<th><?php esc_html_e( 'Email:', 'hotelier' ); ?></th>
			<td><?php echo esc_html( $reservation->guest_email ); ?></td>
		</tr>
	<?php endif; ?>

	<?php if ( $reservation->guest_telephone ) : ?>
		<tr>
			<th><?php esc_html_e( 'Telephone:', 'hotelier' ); ?></th>
			<td><?php echo esc_html( $reservation->guest_telephone ); ?></td>
		</tr>
	<?php endif; ?>

	<?php do_action( 'hotelier_reservation_after_guest_details', $reservation ); ?>
</table>

<header><h3><?php esc_html_e( 'Guest Address', 'hotelier' ); ?></h3></header>

<address>
	<?php echo $reservation->get_formatted_guest_address(); ?>
</address>
