<?php
/**
 * Booking details
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/reservation-details.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="booking-details">

	<header><h3><?php esc_html_e( 'Booking Details', 'hotelier' ); ?></h3></header>

	<?php do_action( 'hotelier_booking_before_booking_details' ); ?>

	<table class="reservation-table hotelier-table">
		<tbody>
			<tr>
				<th><?php esc_html_e( 'Check-in', 'hotelier' ); ?></th>
				<td><?php echo esc_html( $checkin ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Check-out', 'hotelier' ); ?></th>
				<td><?php echo esc_html( $checkout ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Pets', 'hotelier' ); ?></th>
				<td><?php echo esc_html( $pets_message ); ?></td>
			</tr>

			<?php if ( $cards ) : ?>
			<tr>
				<th><?php esc_html_e( 'Accepted credit cards', 'hotelier' ); ?></th>
				<td>
					<ul class="hotelier-accepted-credit-cards">
					<?php foreach ( $cards as $card ) : ?>
						<li class="card-icon <?php echo esc_attr( $card ); ?>"><?php echo esc_html( ucfirst( $card ) ); ?></li>
					<?php endforeach; ?>
					</ul>
				</td>
			</tr>
			<?php endif; ?>

		</tbody>
	</table>

	<?php do_action( 'hotelier_booking_after_booking_details' ); ?>

</div>
