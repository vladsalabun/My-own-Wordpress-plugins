<?php
/**
 * Booking Payment Section
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/payment.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div id="payment">
	<header><h3><?php esc_html_e( 'Payment Method', 'hotelier' ); ?></h3></header>

	<ul class="payment-methods methods">
		<?php
			if ( ! empty( $available_gateways ) ) {
				$single = ( count( $available_gateways ) == 1 ) ? true : false;

				foreach ( $available_gateways as $gateway ) {
					htl_get_template( 'booking/payment-method.php', array( 'gateway' => $gateway, 'single' => $single ) );
				}
			} else {
				echo '<li>' . esc_html__( 'Sorry, it seems that there are no available payment methods. Please contact us if you require assistance.', 'hotelier' ) . '</li>';
			}
		?>
	</ul>
</div>
