<?php
/**
 * Reservation Received Page - This is the page guests are sent to after completing their reservation
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/received.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $reservation ) : ?>

	<?php if ( $reservation->has_status( 'failed' ) ) : ?>

		<p class="reservation-response"><?php esc_html_e( 'Unfortunately your reservation cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'hotelier' ); ?></p>

		<p class="reservation-response-payment-failed">
			<a href="<?php echo esc_url( $reservation->get_booking_payment_url() ); ?>" class="button pay"><?php _e( 'Pay', 'hotelier' ) ?></a>
		</p>

	<?php else : ?>

		<p class="reservation-response"><?php echo apply_filters( 'hotelier_reservation_received_text', esc_html__( 'Thank you. Your reservation has been received.', 'hotelier' ), $reservation ); ?></p>

		<ul class="reservation-details">
			<li class="reservation">
				<?php esc_html_e( 'Reservation Number:', 'hotelier' ); ?>
				<strong><?php echo $reservation->get_reservation_number(); ?></strong>
			</li>
			<li class="date">
				<?php esc_html_e( 'Date:', 'hotelier' ); ?>
				<strong><?php echo date_i18n( get_option( 'date_format' ), strtotime( $reservation->reservation_date ) ); ?></strong>
			</li>
			<li class="checkin">
				<?php esc_html_e( 'Check-in:', 'hotelier' ); ?>
				<strong><?php echo esc_html( $reservation->get_formatted_checkin() ); ?> <span>(<?php echo esc_html( HTL_Info::get_hotel_checkin() ); ?>)</span></strong>
			</li>
			<li class="checkout">
				<?php esc_html_e( 'Check-out:', 'hotelier' ); ?>
				<strong><?php echo esc_html( $reservation->get_formatted_checkout() ); ?> <span>(<?php echo esc_html( HTL_Info::get_hotel_checkout() ); ?>)</span></strong>
			</li>
			<li class="nights">
				<?php esc_html_e( 'Nights:', 'hotelier' ); ?>
				<strong><?php echo esc_html( $reservation->get_nights() ); ?></strong>
			</li>
			<li class="special-requests">
				<strong><?php esc_html_e( 'Special Requests:', 'hotelier' ); ?></strong>
				<span><?php echo esc_html( $reservation->get_guest_special_requests() ? $reservation->get_guest_special_requests() : esc_html__( 'None', 'hotelier' ) ); ?></span>
			</li>
		</ul>

	<?php endif; ?>

	<?php do_action( 'hotelier_received_' . $reservation->payment_method, $reservation->id ); ?>
	<?php do_action( 'hotelier_received', $reservation->id ); ?>

<?php else : ?>

	<p class="reservation-response"><?php esc_html_e( 'Invalid reservation.', 'hotelier' ); ?></p>

		<p><a class="button htl-backward" href="<?php echo esc_url( HTL()->cart->get_room_list_form_url() ); ?>"><?php esc_html_e( 'List of available rooms', 'hotelier' ) ?></a></p>

<?php endif; ?>
