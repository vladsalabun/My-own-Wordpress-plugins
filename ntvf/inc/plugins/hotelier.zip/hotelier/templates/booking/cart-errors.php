<?php
/**
 * Cart errors page
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/cart-errors.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php htl_print_notices(); ?>

<p class="cart-errors"><?php esc_html_e( 'There are some issues with the items in your cart (shown above). Please go back and resolve these issues before the booking.', 'hotelier' ) ?></p>

<?php do_action( 'hotelier_cart_has_errors' ); ?>

<p><a class="button htl-backward" href="<?php echo esc_url( HTL()->cart->get_room_list_form_url() ); ?>"><?php esc_html_e( 'List of available rooms', 'hotelier' ) ?></a></p>
