<?php
/**
 * Pay for reservation form
 *
 * This template can be overridden by copying it to yourtheme/hotelier/booking/form-pay.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<form id="pay-reservation-form" method="post">

	<table class="reservation-table hotelier-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Room', 'hotelier' ); ?></th>
				<th><?php esc_html_e( 'Qty', 'hotelier' ); ?></th>
				<th><?php esc_html_e( 'Cost', 'hotelier' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php
				foreach( $reservation->get_items() as $item_id => $item ) {
					$room = $reservation->get_room_from_item( $item );

					htl_get_template( 'reservation/item.php', array(
						'reservation' => $reservation,
						'item_id'     => $item_id,
						'item'        => $item,
						'room'        => $room,
					) );
				}
			?>
		</tbody>
		<tfoot>
			<?php
			if ( $totals = $reservation->get_totals_before_booking() ) :
				foreach ( $totals as $total ) : ?>
					<tr>
						<th colspan="2"><?php echo esc_html( $total[ 'label' ] ); ?></th>
						<td><strong><?php echo $total[ 'value' ]; ?></strong></td>
					</tr>
				<?php endforeach;
			endif; ?>
		</tfoot>
	</table>

	<?php if ( $reservation->needs_payment() ) : ?>

		<div id="payment">
			<header><h3><?php esc_html_e( 'Payment Method', 'hotelier' ); ?></h3></header>

			<ul class="payment-methods methods">
				<?php
					if ( ! empty( $available_gateways ) ) {
						$single = ( count( $available_gateways ) == 1 ) ? true : false;

						foreach ( $available_gateways as $gateway ) {
							htl_get_template( 'booking/payment-method.php', array( 'gateway' => $gateway, 'single' => $single ) );
						}
					} else {
						echo '<li>' . esc_html__( 'Sorry, it seems that there are no available payment methods. Please contact us if you require assistance.', 'hotelier' ) . '</li>';
					}
				?>
			</ul>

			<div class="form-row">

				<input type="hidden" name="hotelier_pay" value="1" />

				<?php echo apply_filters( 'hotelier_book_button_html', '<input type="submit" class="button" id="book-button" value="' . esc_attr( $reservation_button_text ) . '" />' ); ?>

				<?php wp_nonce_field( 'hotelier-pay' ); ?>
			</div>

		</div>

	<?php endif; ?>

</form>
