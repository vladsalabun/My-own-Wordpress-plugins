<?php
/**
 * Room rates.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/rates.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

if ( ! $room->is_variable_room() ) {
	return;
}

?>

<div class="room-rates">

	<h3><?php esc_html_e( 'Available rates', 'hotelier' ); ?></h3>

	<ul id="room-rates-<?php echo absint( get_the_ID() ); ?>" class="rate-list">

		<?php
		$varitations = $room->get_room_variations();

		// Print room rates
		foreach ( $varitations as $variation ) :
			$variation = new HTL_Room_Variation( $variation ); ?>

			<li class="room-single-rate">

				<div class="rate-description-wrapper">

					<h4 class="rate-name"><?php echo esc_html( $variation->get_formatted_room_rate() ); ?></h4>

					<?php if ( $description = $variation->get_room_description() ) : ?>

						<div class="rate-description"><?php echo wp_kses( $variation->get_room_description(), array( 'p' => array() ) ); ?></div>

					<?php endif; ?>

					<?php if ( $variation->has_conditions() ) : ?>

						<div class="rate-conditions">

							<span><?php esc_html_e( 'Rate Conditions:', 'hotelier' ) ?></span>

							<ul>

							<?php foreach ( $variation->get_room_conditions() as $condition ) : ?>

								<li><?php echo esc_html( $condition ); ?></li>

							<?php endforeach; ?>

							</ul>

						</div>

					<?php endif; ?>

				</div>

				<div class="rate-price-wrapper">

					<div class="rate-price">
						<span class="price"><?php echo $variation->get_min_price_html(); ?></span>
					</div>

					<?php if ( htl_get_option( 'booking_mode' ) != 'no-booking' ) : ?>

						<p><a href="#hotelier-datepicker" class="button"><?php esc_html_e( 'Check Availability', 'hotelier' ) ?></a></p>

					<?php endif; ?>

					<?php if ( $variation->needs_deposit() ) : ?>

						<div class="rate-deposit">
							<span class="deposit-label"><?php esc_html_e( 'Deposit Required', 'hotelier' ); ?></span>
							<span class="deposit-amount"><?php echo esc_html( $variation->get_formatted_deposit() ); ?></span>
						</div>

					<?php endif; ?>

				</div>

			</li>

		<?php endforeach; ?>
	</ul>

</div>
