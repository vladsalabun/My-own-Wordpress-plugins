<?php
/**
 * Room facilities.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/facilities.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<?php if ( $facilities = $room->get_facilities() ) : ?>

<div class="room-facilities">

	<h3><?php esc_html_e( 'Facilities', 'hotelier' ); ?></h3>

	<p><?php echo $facilities; ?></p>

</div>

<?php endif; ?>
