<?php
/**
 * Room gallery.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/gallery.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

// Do not show the gallery button if the room has not images
// but close the .post-thumbnail div before return!!!
if ( ! $room->get_gallery_attachment_ids() ) {
	echo '</div><!-- .post-thumbnail -->';
	return;
}

$gallery_images = array();

if ( has_post_thumbnail() ) {
	$image         = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
	$image_link    = esc_url( $image[ 0 ] );
	$image_width   = absint( $image[ 1 ] );
	$image_height  = absint( $image[ 2 ] );
	$image_title   = get_post( get_post_thumbnail_id() )->post_title;
	$image_caption = get_post( get_post_thumbnail_id() )->post_excerpt;

	$gallery_images[] = array(
		'name'   => esc_html( $image_title ),
		'url'    => $image_link,
		'title'  => esc_attr( $image_caption ),
		'width'  => $image_width,
		'height' => $image_height,
	);
}

$attachment_ids = $room->get_gallery_attachment_ids();

foreach ( $attachment_ids as $attachment_id ) {
	$attachment  = wp_get_attachment_image_src( $attachment_id, 'full' );

	if ( ! $attachment ) {
		continue;
	}

	$attachment_link    = esc_url( $attachment[ 0 ] );
	$attachment_width   = absint( $attachment[ 1 ] );
	$attachment_height  = absint( $attachment[ 2 ] );
	$attachment_title   = get_post_field( 'post_title', $attachment_id );
	$attachment_caption = get_post_field( 'post_excerpt', $attachment_id );

	$gallery_images[] = array(
		'name'   => esc_html( $attachment_title ),
		'url'    => $attachment_link,
		'title'  => esc_attr( $attachment_caption ),
		'width'  => $attachment_width,
		'height' => $attachment_height,
	);
}

?>

<?php if ( $gallery_images ) :
	$i = 0; ?>

	<div class="room-gallery">

		<a href="#" class="show-gallery"  data-index="0"><?php esc_html_e( 'View room gallery', 'hotelier' ); ?></a>

		<ul style="display:none">

			<?php foreach ( $gallery_images as $gallery_image ) : ?>

				<li><a href="<?php echo $gallery_image[ 'url' ]; ?>" data-size="<?php echo $gallery_image[ 'width' ]; ?>x<?php echo $gallery_image[ 'height' ]; ?>" data-index="<?php echo absint( $i ); ?>" class="room-thumbnail" title="<?php echo $gallery_image[ 'title' ]; ?>"><?php echo $gallery_image[ 'name' ]; ?></a></li>

			<?php
			$i ++;
			endforeach; ?>

		</ul>

	</div>
<?php endif; ?>

</div><!-- .post-thumbnail -->
