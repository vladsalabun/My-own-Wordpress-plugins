<?php
/**
 * Related rooms.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/related.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room, $hotelier_loop;

$categories = $room->get_terms_related();

if ( sizeof( $categories ) === 0 ) {
	return;
}

$args = apply_filters( 'hotelier_related_rooms_args', array(
	'post_type'            => 'room',
	'ignore_sticky_posts'  => 1,
	'no_found_rows'        => 1,
	'posts_per_page'       => $posts_per_page,
	'orderby'              => $orderby,
	'post__not_in'         => array( $room->id ),
	'tax_query'            => array(
		array(
			'taxonomy' => 'room_cat',
			'field' => 'id',
			'terms' => $categories
		)
	)
) );

$rooms = new WP_Query( $args );

$hotelier_loop[ 'columns' ] = $columns;

if ( $rooms->have_posts() ) : ?>

	<div class="related-rooms">

		<h3><?php _e( 'Related Rooms', 'hotelier' ); ?></h3>

		<div class="hotelier columns-<?php echo absint( $columns ); ?>">

			<?php hotelier_room_loop_start(); ?>

				<?php while ( $rooms->have_posts() ) : $rooms->the_post(); ?>

					<?php htl_get_template_part( 'archive/content', 'room' ); ?>

				<?php endwhile; // end of the loop. ?>

			<?php hotelier_room_loop_end(); ?>

		</div>

	</div>

<?php endif;

wp_reset_postdata();
