<?php
/**
 * Room description (post content).
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/description.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php the_content(); ?>
