<?php
/**
 * Room price.
 *
 * This template can be overridden by copying it to yourtheme/hotelier/single-room/price.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $room;

?>

<div class="room-price">
	<span class="price"><?php echo $room->get_min_price_html(); ?></span>

	<?php if ( $room->is_variable_room() ) : ?>

		<p class="available-rates"><a href="#room-rates-<?php echo absint( get_the_ID() ); ?>"><?php esc_html_e( 'See available rates', 'hotelier' ); ?></a></p>

	<?php endif; ?>
</div>
