<?php
/**
 * Displayed when no rooms are found matching the current query
 *
 * This template can be overridden by copying it to yourtheme/hotelier/loop/no-rooms-found.php.
 *
 * @author  Lollum
 * @package Hotelier/Templates
 * @version 0.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<p class="no-rooms-found"><?php esc_html_e( 'No rooms were found matching your selection.', 'hotelier' ); ?></p>
