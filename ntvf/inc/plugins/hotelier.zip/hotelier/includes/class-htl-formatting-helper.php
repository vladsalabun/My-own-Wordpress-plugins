<?php
/**
 * Hotelier Formatting Functions.
 *
 * @author   Lollum
 * @category Class
 * @package  Hotelier/Classes
 * @version  0.9.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'HTL_Formatting_Helper' ) ) :

/**
 * HTL_Formatting_Helper Class
 */
class HTL_Formatting_Helper {
	/**
	 * Format and store prices as integers
 	 *
 	 * Sanitize and remove locale formatting
	 */
	public static function sanitize_amount( $amount ) {
		$is_negative   = false;
		$thousands_sep = htl_get_price_thousand_separator();
		$decimal_sep   = htl_get_price_decimal_separator();

		// Sanitize the amount
		if ( $decimal_sep == ',' && false !== ( $found = strpos( $amount, $decimal_sep ) ) ) {
			if ( ( $thousands_sep == '.' || $thousands_sep == ' ' ) && false !== ( $found = strpos( $amount, $thousands_sep ) ) ) {
				$amount = str_replace( $thousands_sep, '', $amount );
			} elseif( empty( $thousands_sep ) && false !== ( $found = strpos( $amount, '.' ) ) ) {
				$amount = str_replace( '.', '', $amount );
			}

			$amount = str_replace( $decimal_sep, '.', $amount );
		} elseif( $thousands_sep == ',' && false !== ( $found = strpos( $amount, $thousands_sep ) ) ) {
			$amount = str_replace( $thousands_sep, '', $amount );
		}

		if ( $amount < 0 ) {
			$is_negative = true;
		}

		$amount = preg_replace( '/[^0-9\.]/', '', $amount );

		if ( $is_negative ) {
			$amount *= -1;
		}

		// Here we have a sanitized amount with . as a decimal separator
		// Store it as integer - e.g. 100.50 and 100.5 become 10050
		$amount = $amount * 100;

		return ( int ) $amount;
	}

	/**
	 * Format a price with Currency Locale settings
	 */
	public static function localized_amount( $amount ) {
		$thousands_sep = htl_get_price_thousand_separator();
		$decimal_sep   = htl_get_price_decimal_separator();
		$decimals      = htl_get_price_decimals();

		if ( $amount ) {
			$amount = $amount / 100;
			$amount = number_format( (double) $amount, $decimals, $decimal_sep, '' );
		} else {
			$amount = '';
		}

		return $amount;
	}

	/**
	 * Transforms the php.ini notation for numbers to an integer.
	 */
	public static function notation_to_int( $size ) {
		$l   = substr( $size, -1 );
		$ret = substr( $size, 0, -1 );

		switch ( strtoupper( $l ) ) {
			case 'P':
				$ret *= 1024;
			case 'T':
				$ret *= 1024;
			case 'G':
				$ret *= 1024;
			case 'M':
				$ret *= 1024;
			case 'K':
				$ret *= 1024;
		}

		return $ret;
	}

	/**
	 * Validates a phone number.
	 */
	public static function is_phone( $number ) {
		if ( 0 < strlen( trim( preg_replace( '/[\s\#0-9_\-\+\(\)]/', '', $number ) ) ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Formats a phone number.
	 */
	public static function validate_phone( $number ) {
		$tel = str_replace( '.', '-', $number );

		return $number;
	}

	/**
	 * Validates date in format YYYY-MM-DD.
	 * @param string $date
	 * @return bool
	 */
	public static function is_valid_date( $date ) {
		$date_regex = '/^(19|20)\d\d[\-\/.](0[1-9]|1[012])[\-\/.](0[1-9]|[12][0-9]|3[01])$/';

		if ( ! preg_match( $date_regex, $date ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Validates checkin and checkout dates.
	 * @param string $checkin
	 * @param string $checkout
	 * @return bool
	 */
	public static function is_valid_checkin_checkout( $checkin, $checkout ) {
		// Check if $checkin and $checkout are valid dates
		if ( ! self::is_valid_date( $checkin ) || ! self::is_valid_date( $checkout ) ) {
			return false;
		}

		// Only allow reservations for "XX" months from current date (0 unlimited).
		$months_advance = htl_get_option( 'booking_months_advance', 0 );

		// Check if arrival date must be "XX" days from current date.
		$arrival_date = htl_get_option( 'booking_arrival_date', 0 );

		// Get dates
		$curdate  = new DateTime( current_time( 'Y-m-d' ) );
		$checkin  = new DateTime( $checkin );
		$checkout = new DateTime( $checkout );

		// Check if $checkin greater than today
		if ( $checkin < $curdate ) {
			return false;
		}

		// Check if $checkout greater than $checkin
		if ( $checkin >= $checkout ) {
			return false;
		}

		// Check if arrival date is "XX" days from current date
		$diff = date_diff( $curdate, $checkin );
		if ( $diff->days < $arrival_date ) {
			return false;
		}

		// Check if arrival date is "XX" months from current date

		if ( $months_advance !== 0 ) {
			if ( ( $diff->m + $diff->y*12 ) >= 1 ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Validates a date range.
	 * @param string $checkin
	 * @param string $checkout
	 * @return bool
	 */
	public static function is_valid_date_range( $from, $to ) {
		// Check if $from and $to are valid dates
		if ( ! self::is_valid_date( $from ) || ! self::is_valid_date( $to ) ) {
			return false;
		}

		// Get dates
		$curdate  = new DateTime( current_time( 'Y-m-d' ) );
		$from  = new DateTime( $from );
		$to = new DateTime( $to );

		// Check if $from greater than today
		if ( $from < $curdate ) {
			return false;
		}

		// Check if $to greater than $from
		if ( $from >= $to ) {
			return false;
		}

		return true;
	}

	/**
	 * Trim a string and append a suffix
	 * @param  string  $string
	 * @param  integer $chars
	 * @param  string  $suffix
	 * @return string
	 */
	public static function trim_string( $string, $chars = 200, $suffix = '...' ) {
		if ( strlen( $string ) > $chars ) {
			$string = substr( $string, 0, ( $chars - strlen( $suffix ) ) ) . $suffix;
		}
		return $string;
	}

	/**
	 * Sanitizes a string key for Hotelier Settings
	 * @param  string  $key
	 * @return string
	 */
	public static function sanitize_key( $key ) {
		$raw_key = $key;
		$key = preg_replace( '/[^a-zA-Z0-9_\-\.\:\/]/', '', $key );

		return $key;
	}
}

endif;
