<?php
/**
 * Functions for the templating system.
 *
 * @author   Lollum
 * @category Core
 * @package  Hotelier/Functions
 * @version  0.9.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_filter( 'body_class', 'htl_body_class' );

/**
 * Output Hotelier generator tag
 */
add_action( 'get_the_generator_html', 'htl_generator_tag', 10, 2 );
add_action( 'get_the_generator_xhtml', 'htl_generator_tag', 10, 2 );

/**
 * Global
 */
add_action( 'hotelier_before_main_content', 'hotelier_output_content_wrapper', 10 );
add_action( 'hotelier_after_main_content', 'hotelier_output_content_wrapper_end', 10 );
add_action( 'hotelier_sidebar', 'hotelier_get_sidebar', 10 );
add_action( 'hotelier_pagination', 'hotelier_pagination', 10 );

/**
 * Single Room
 */
add_action( 'hotelier_single_room_images', 'hotelier_template_single_room_image', 10 );
add_action( 'hotelier_single_room_images', 'hotelier_template_single_room_gallery', 20 );
add_action( 'hotelier_single_room_title', 'hotelier_template_single_room_title', 10 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_datepicker', 5 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_price', 10 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_deposit', 20 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_meta', 30 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_facilities', 40 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_conditions', 50 );
add_action( 'hotelier_single_room_details', 'hotelier_template_single_room_sharing', 60 );
add_action( 'hotelier_single_room_description', 'hotelier_template_single_room_description', 10 );
add_action( 'hotelier_single_room_rates', 'hotelier_template_single_room_rates', 10 );
add_action( 'hotelier_output_related_rooms', 'hotelier_template_related_rooms', 10 );

/**
 * Archive Loop Items
 */
add_action( 'hotelier_archive_description', 'hotelier_taxonomy_archive_description', 10 );
add_action( 'hotelier_before_archive_room_loop', 'hotelier_before_archive_room_loop', 10 );
add_action( 'hotelier_after_archive_room_loop', 'hotelier_output_loop_wrapper_end', 10 );
add_action( 'hotelier_archive_item_room', 'hotelier_template_archive_room_image', 5 );
add_action( 'hotelier_archive_item_room', 'hotelier_template_archive_room_title', 10 );
add_action( 'hotelier_archive_item_room', 'hotelier_template_archive_room_description', 20 );
add_action( 'hotelier_archive_item_room', 'hotelier_template_archive_room_price', 30 );
add_action( 'hotelier_archive_item_room', 'hotelier_template_archive_room_more', 40 );

/**
 * Room Loop Items
 */
add_action( 'hotelier_room_list_datepicker', 'hotelier_template_datepicker', 10 );
add_action( 'hotelier_room_list_selected_nights', 'hotelier_template_selected_nights', 10 );
add_action( 'hotelier_room_list_item_title', 'hotelier_template_rooms_left', 10 );
add_action( 'hotelier_room_list_item_title', 'hotelier_template_room_list_title', 20 );
add_action( 'hotelier_room_list_item_images', 'hotelier_template_loop_room_image', 10 );
add_action( 'hotelier_room_list_item_images', 'hotelier_template_loop_room_thumbnails', 20 );
add_action( 'hotelier_room_list_item_content', 'hotelier_template_loop_room_short_description', 10 );
add_action( 'hotelier_room_list_item_meta', 'hotelier_template_loop_room_facilities', 10 );
add_action( 'hotelier_room_list_item_meta', 'hotelier_template_loop_room_meta', 15 );
add_action( 'hotelier_room_list_item_meta', 'hotelier_template_loop_room_conditions', 20 );
add_action( 'hotelier_room_list_item_deposit', 'hotelier_template_loop_room_deposit', 10 );
add_action( 'hotelier_room_list_item_guests', 'hotelier_template_loop_room_guests', 10 );
add_action( 'hotelier_room_list_item_price', 'hotelier_template_loop_room_price', 10 );

// Hide book button when booking_mode is set to 'no-booking'
if ( htl_get_option( 'booking_mode' ) != 'no-booking' ) {
	add_action( 'hotelier_room_list_item_add_to_cart', 'hotelier_template_loop_room_add_to_cart', 10 );
	add_action( 'hotelier_reserve_button', 'hotelier_template_loop_room_reserve_button', 10 );
}

/**
 * Reservation details
 */
add_action( 'hotelier_received', 'hotelier_reservation_table', 10 );
