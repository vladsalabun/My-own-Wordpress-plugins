<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Room Search Widget.
 *
 * @author   Lollum
 * @category Widgets
 * @package  Hotelier/Widgets
 * @version  0.9.0
 * @extends  HTL_Widget
 */

class HTL_Widget_Room_Search extends HTL_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->widget_cssclass    = 'hotelier widget-hotelier widget-hotelier-search';
		$this->widget_description = esc_html__( 'A search box for rooms only.', 'hotelier' );
		$this->widget_id          = 'hotelier-widget-room-search';
		$this->widget_name        = esc_html__( 'Hotelier Room Search', 'hotelier' );
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Title', 'hotelier' )
			)
		);

		parent::__construct();
	}

	/**
	 * widget function.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		$this->widget_start( $args, $instance );

		?>

		<form role="search" method="get" class="hotelier-room-search" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
			<label class="screen-reader-text" for="s"><?php esc_html_e( 'Search for:', 'hotelier' ); ?></label>
			<input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search Rooms&hellip;', 'placeholder', 'hotelier' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'hotelier' ); ?>" />
			<input type="submit" value="<?php echo esc_attr_x( 'Search', 'submit button', 'hotelier' ); ?>" />
			<input type="hidden" name="post_type" value="room" />
		</form>

		<?php
		$this->widget_end( $args );
	}
}
