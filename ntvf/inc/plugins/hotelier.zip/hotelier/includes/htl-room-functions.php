<?php
/**
 * Hotelier Room Functions.
 *
 * @author   Lollum
 * @category Core
 * @package  Hotelier/Functions
 * @version  0.9.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Main function for returning rooms.
 *
 * @param  mixed $the_room Post object or post ID of the room.
 * @return HTL_Room
 */
function htl_get_room( $the_room = false ) {
	return new HTL_Room( $the_room );
}

/**
 * Get the placeholder image URL for rooms etc
 *
 * @access public
 * @return string
 */
function htl_placeholder_img_src() {
	return apply_filters( 'hotelier_placeholder_img_src', HTL()->plugin_url() . '/assets/images/placeholder.png' );
}

/**
 * Get the placeholder image
 *
 * @access public
 * @return string
 */
function htl_placeholder_img( $size = 'room_thumbnail' ) {
	$dimensions = htl_get_image_size( $size );

	return apply_filters( 'hotelier_placeholder_img', '<img src="' . htl_placeholder_img_src() . '" alt="' . esc_attr__( 'Placeholder', 'hotelier' ) . '" width="' . esc_attr( $dimensions[ 'width' ] ) . '" class="hotelier-placeholder wp-post-image" height="' . esc_attr( $dimensions[ 'height' ] ) . '" />', $size, $dimensions );
}

/**
 * Function that returns an array containing the IDs of the rooms that are reserved on the given dates.
 *
 * @access public
 * @param string $checkin
 * @param string $checkout
 * @param array $args
 * @return array on success or false on failure.
 */
function htl_get_room_ids_unavailable( $checkin, $checkout, $args = array() ) {

	// Check if we want to show also the unavailable rooms
	if ( htl_get_option( 'room_unavailable_visibility', false ) ) {
		return array();
	}

	try {
		global $wpdb;

		if ( ! HTL_Formatting_Helper::is_valid_checkin_checkout( $checkin, $checkout ) ) {
			throw new Exception( esc_html__( 'Please check your dates.', 'hotelier' ) );
		}

		// query already reserved rooms and check if there is enough stock
		$sql            = $wpdb->prepare( "SELECT room_id, count(room_id) AS count FROM {$wpdb->prefix}hotelier_rooms_bookings rb, {$wpdb->prefix}hotelier_bookings b WHERE rb.reservation_id = b.reservation_id AND (%s < b.checkout AND %s > b.checkin) GROUP by room_id", $checkin, $checkout );
		$reserved_rooms = $wpdb->get_results( $sql, ARRAY_A );

		$ids = array();

		if ( ! empty( $reserved_rooms ) ) {
			foreach ( $reserved_rooms as $id => $row ) {
				$_room = htl_get_room( $row[ 'room_id' ] );

				if ( $_room->exists() ) {
					if ( ! $_room->is_available( $checkin, $checkout ) ) {
						$ids[] = $row[ 'room_id' ];
					}
				}
			}
		}

		return apply_filters( 'hotelier_get_room_ids_unavailable', $ids );

	} catch ( Exception $e ) {
		if ( $e->getMessage() ) {
			htl_add_notice( $e->getMessage(), 'error' );
		}
		return false;
	}
}

/**
 * Gets a list of all rooms (in HTML).
 *
 * @access public
 * @param string $name
 * @return string
 */
function htl_get_list_of_rooms_html( $name ) {

	// Query args
	$args = array(
		'post_type'           => 'room',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => 1,
		'posts_per_page'      => -1,
		'orderby'             => 'title',
		'order'               => 'ASC',
		'meta_query'          => array(
			array(
				'key'     => '_stock_rooms',
				'value'   => 0,
				'compare' => '>',
			),
		),
	);

	$select = '';

	$rooms = new WP_Query( $args );

	if ( $rooms->have_posts() ) {
		$select = '<select name="' . esc_attr( $name ) . '">';

		while ( $rooms->have_posts() ) {
			$rooms->the_post();

			global $room;

			if ( $room->is_variable_room() ) {
				$varitations = $room->get_room_variations();

				$select .= '<optgroup label="' . get_the_title() . '">';

				foreach ( $varitations as $variation ) {

					$variation = new HTL_Room_Variation( $variation );
					$select .= '<option value="'  . $room->id . '-' . $variation->get_room_index() . '">' . $variation->get_formatted_room_rate() . '</option>';
				}

				$select .= '</optgroup>';
			} else {
				$select .= '<option value="'  . $room->id . '-0">' . get_the_title() . '</option>';
			}
		}

		$select .= '</select>';

		wp_reset_postdata();
	}

	return $select;
}

/**
 * Get the price breakdown of a room.
 *
 * @access public
 * @param string $checkin
 * @param string $checkout
 * @param int $room_id
 * @param int $rate_id
 * @return string
 */
function htl_get_room_price_breakdown( $checkin, $checkout, $room_id, $rate_id, $qty ) {
	$_room        = htl_get_room( $room_id );
	$is_variable  = $_room->is_variable_room() ? true : false;
	$checkin_obj  = new DateTime( $checkin );
	$checkout_obj = new DateTime( $checkout );
	$interval     = new DateInterval( 'P1D' );
	$daterange    = new DatePeriod( $checkin_obj, $interval ,$checkout_obj );

	$breakdown = array();

	if ( $is_variable ) {

		$_variation = $_room->get_room_variation( $rate_id );

		if ( $_variation->is_on_sale( $checkin, $checkout ) ) {

			if ( $_variation->is_price_per_day() ) {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'sale_price_day' ][ $date->format( 'w' ) ] * $qty;
				}
			} else {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'sale_price' ] * $qty;
				}
			}

		} else {

			if ( $_variation->has_seasonal_price() ) {
				// seasonal price schema
				$rules = htl_get_seasonal_prices_schema();

				if ( is_array( $rules ) ) {
					// Reverse the array, last rules have a higher precedence
					$rules = array_reverse( $rules );
				}

				foreach( $daterange as $date ) {
					$curr_date = $date->getTimestamp();

					if ( $rules ) {
						$has_seasonal_price = false;

						foreach ( $rules as $key => $rule ) {
							$begin = new DateTime( $rule[ 'from' ] );
							$end = new DateTime( $rule[ 'to' ] );

							if ( $curr_date >= $begin->getTimestamp() && $curr_date <= $end->getTimestamp() ) {

								if ( isset( $_variation->variation[ 'seasonal_price' ][ $rule[ 'index' ] ] ) ) {
									// Rule found, use seasonal price
									$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'seasonal_price' ][ $rule[ 'index' ] ] * $qty;
									$has_seasonal_price = true;
								}

								break;
							}
						}

						if ( ! $has_seasonal_price ) {
							// Rule not found, use default price
							$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'seasonal_base_price' ] * $qty;
						}
					}
				}
			} else if ( $_variation->is_price_per_day() ) {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'price_day' ][ $date->format( 'w' ) ] * $qty;
				}
			} else {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_variation->variation[ 'regular_price' ] * $qty;
				}
			}
		}

	} else {

		if ( $_room->is_on_sale( $checkin, $checkout ) ) {

			if ( $_room->is_price_per_day() ) {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->sale_price_day[ $date->format( 'w' ) ] * $qty;
				}
			} else {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->sale_price * $qty;
				}
			}

		} else {

			if ( $_room->has_seasonal_price() ) {
				// seasonal price schema
				$rules = htl_get_seasonal_prices_schema();

				if ( is_array( $rules ) ) {
					// Reverse the array, last rules have a higher precedence
					$rules = array_reverse( $rules );
				}

				foreach( $daterange as $date ) {
					$curr_date = $date->getTimestamp();

					if ( $rules ) {
						$has_seasonal_price = false;

						foreach ( $rules as $key => $rule ) {
							$begin = new DateTime( $rule[ 'from' ] );
							$end = new DateTime( $rule[ 'to' ] );

							if ( $curr_date >= $begin->getTimestamp() && $curr_date <= $end->getTimestamp() ) {

								if ( isset( $_room->seasonal_price[ $rule[ 'index' ] ] ) ) {
									// Rule found, use seasonal price
									$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->seasonal_price[ $rule[ 'index' ] ] * $qty;
									$has_seasonal_price = true;
								}

								break;
							}
						}

						if ( ! $has_seasonal_price ) {
							// Rule not found, use default price
							$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->seasonal_base_price * $qty;
						}
					}
				}
			} else if ( $_room->is_price_per_day() ) {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->regular_price_day[ $date->format( 'w' ) ] * $qty;
				}
			} else {
				foreach( $daterange as $date ) {
					$breakdown[ $date->format( 'Y-m-d' ) ] = $_room->regular_price * $qty;
				}
			}
		}
	}

	return $breakdown;
}
