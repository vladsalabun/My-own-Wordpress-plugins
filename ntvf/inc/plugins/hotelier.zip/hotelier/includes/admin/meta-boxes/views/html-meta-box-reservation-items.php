<?php
/**
 * Shows the items (rooms) attached to the reservation
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Get line items
$line_items = $reservation->get_items();
?>

<div class="hotelier-reservation-items-wrapper">
	<table cellpadding="0" cellspacing="0" class="hotelier_reservation_items">
		<thead>
			<tr>
				<th class="room-name" colspan="2"><?php esc_html_e( 'Room', 'hotelier' ); ?></th>

				<?php do_action( 'hotelier_admin_reservation_item_headers', $reservation ); ?>

				<th class="room-guests"><?php esc_html_e( 'Guests', 'hotelier' ); ?></th>
				<th class="room-price"><?php esc_html_e( 'Price', 'hotelier' ); ?></th>
				<th class="room-qty"><?php esc_html_e( 'Qty', 'hotelier' ); ?></th>
				<th class="room-total"><?php esc_html_e( 'Total', 'hotelier' ); ?></th>
			</tr>
		</thead>

		<tbody>
		<?php
			foreach ( $line_items as $item_id => $item ) {
				$_room     = $reservation->get_room_from_item( $item );
				$item_meta = $reservation->get_item_meta( $item_id );

				include( 'html-meta-box-reservation-single-item.php' );

				// do_action( 'hotelier_reservation_item_html', $item_id, $item, $reservation );
			}
		?>
		</tbody>
	</table>
</div>

<div class="hotelier-reservation-items-wrapper">
	<table class="hotelier-reservation-totals">

		<?php if ( $reservation->has_room_with_deposit() ) : ?>

			<tr class="subtotal">
				<td class="label"><?php esc_html_e( 'Total Charge', 'hotelier' ); ?>:</td>
				<td class="total">
					<?php echo htl_price( htl_convert_to_cents( $reservation->get_total() ), $reservation->get_reservation_currency() ); ?>
				</td>
			</tr>

			<tr class="deposit">

				<td class="label">
					<?php if ( $reservation->get_paid_deposit() > 0 ) {
						echo esc_html__( 'Paid Deposit', 'hotelier' );
					} else {
						echo esc_html__( 'Deposit Due', 'hotelier' );
					} ?>:
				</td>

				<td class="total">
					<ul>
					<?php foreach ( $line_items as $item ) :
						if ( $item[ 'deposit' ] > 0 ) :
							$rate_name = isset( $item[ 'rate_name' ] ) ? htl_get_formatted_room_rate( $item[ 'rate_name' ] ) : '';
							?>
							<li>
								<span class="item-name hastip" title="<?php echo esc_attr( $rate_name ); ?>"><?php echo esc_html( $item[ 'name' ] ); ?></span>
								<span class="deposit"><?php echo absint( $item[ 'deposit' ] ); ?>%</span>
								<span class="line-deposit"><?php echo htl_calculate_deposit( $item[ 'total' ], $item[ 'deposit' ], $reservation->get_reservation_currency() ); ?></span>
							</li>
						<?php
						endif;
					endforeach; ?>
					</ul>

					<span class="deposit-total <?php echo ( $reservation->get_paid_deposit() > 0 ) ? '' : 'due'; ?>"><?php echo htl_price( htl_convert_to_cents( $reservation->get_deposit(), $reservation->get_reservation_currency() ) ); ?></span>
				</td>
			</tr>

		<?php endif; ?>

		<tr class="total">
			<td class="label"><?php esc_html_e( 'Balance Due', 'hotelier' ); ?>:</td>
			<td class="total">
				<?php echo htl_price( htl_convert_to_cents( $reservation->get_balance_due() ), $reservation->get_reservation_currency() ); ?>
			</td>
		</tr>

	</table>
</div>
