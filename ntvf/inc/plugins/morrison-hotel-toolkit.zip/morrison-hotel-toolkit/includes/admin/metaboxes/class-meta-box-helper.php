<?php
/**
 * Meta Boxes Functions.
 *
 * @author   Lollum
 * @category Admin
 * @package  Morrison_Hotel_Toolkit/Admin/Meta Boxes
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Meta_Box_Helper' ) ) :

/**
 * MH_TKT_Meta_Box_Helper Class
 */
class MH_TKT_Meta_Box_Helper {

	/**
	 * Output a text input box.
	 */
	public static function text_input( $field ) {
		global $thepostid, $post;

		$thepostid                = empty( $thepostid ) ? $post->ID : $thepostid;

		$field[ 'placeholder' ]   = isset( $field[ 'placeholder' ] ) ? $field[ 'placeholder' ] : '';
		$field[ 'wrapper_class' ] = isset( $field[ 'wrapper_class' ] ) ? $field[ 'wrapper_class' ] : '';
		$field[ 'class' ]         = isset( $field[ 'class' ] ) ? $field[ 'class' ] : '';
		$field[ 'value' ]         = isset( $field[ 'value' ] ) ? $field[ 'value' ] : get_post_meta( $thepostid, $field[ 'id' ], true );
		$field[ 'name' ]          = isset( $field[ 'name' ] ) ? $field[ 'name' ] : $field[ 'id' ];
		$field[ 'label' ]         = isset( $field[ 'label' ] ) ? $field[ 'label' ] : '';
		$field[ 'type' ]          = isset( $field[ 'type' ] ) ? $field[ 'type' ] : 'text';

		$field_id = 'id="' . esc_attr( $field[ 'id' ] ) . '"';

		if ( get_post_meta( $thepostid, $field[ 'id' ], true ) ) {
			$field[ 'value' ] = get_post_meta( $thepostid, $field[ 'id' ], true );
		}

		echo '<p class="form-field ' . esc_attr( $field[ 'wrapper_class' ] ) . '"><label><span>' . wp_kses_post( $field[ 'label' ] ) . '</span><input type="' . esc_attr( $field[ 'type' ] ) . '" class="' . esc_attr( $field[ 'class' ] ) . '" name="' . esc_attr( $field[ 'name' ] ) . '" value="' . esc_attr( $field[ 'value' ] ) . '" placeholder="' . esc_attr( $field[ 'placeholder' ] ) . '" ' . $field_id . ' /></label>';

		if ( ! empty( $field[ 'description' ] ) ) {
			echo '<span class="description">' . wp_kses_post( $field[ 'description' ] ) . '</span>';
		}

		echo '</p>';
	}

	/**
	 * Output a checkbox input box.
	 */
	public static function checkbox_input( $field ) {
		global $thepostid, $post;

		$thepostid                = empty( $thepostid ) ? $post->ID : $thepostid;

		$field[ 'wrapper_class' ] = isset( $field[ 'wrapper_class' ] ) ? $field[ 'wrapper_class' ] : '';
		$field[ 'class' ]         = isset( $field[ 'class' ] ) ? $field[ 'class' ] : '';
		$field[ 'value' ]         = get_post_meta( $thepostid, $field[ 'id' ], true );
		$field[ 'name' ]          = isset( $field[ 'name' ] ) ? $field[ 'name' ] : $field[ 'id' ];
		$field[ 'label' ]         = isset( $field[ 'label' ] ) ? $field[ 'label' ] : '';

		$field_id = 'id="' . esc_attr( $field[ 'id' ] ) . '"';

		$checked = checked( 1, $field[ 'value' ], false );

		echo '<p class="form-field ' . esc_attr( $field[ 'wrapper_class' ] ) . '"><label><span>' . wp_kses_post( $field[ 'label' ] ) . '</span><input type="checkbox" class="' . esc_attr( $field[ 'class' ] ) . '" name="' . esc_attr( $field[ 'name' ] ) . '" value="1" ' . $checked . ' ' . $field_id . ' /></label>';

		if ( ! empty( $field[ 'description' ] ) ) {
			echo '<span class="description checkbox-description">' . wp_kses_post( $field[ 'description' ] ) . '</span>';
		}

		echo '</p>';
	}

	/**
	 * Output a select input box.
	 */
	public static function select_input( $field ) {
		global $thepostid, $post;

		$thepostid                = empty( $thepostid ) ? $post->ID : $thepostid;

		$field[ 'wrapper_class' ] = isset( $field[ 'wrapper_class' ] ) ? $field[ 'wrapper_class' ] : '';
		$field[ 'class' ]         = isset( $field[ 'class' ] ) ? $field[ 'class' ] : '';
		$field[ 'value' ]         = isset( $field[ 'value' ] ) ? $field[ 'value' ] : get_post_meta( $thepostid, $field[ 'id' ], true );
		$field[ 'name' ]          = isset( $field[ 'name' ] ) ? $field[ 'name' ] : $field[ 'id' ];
		$field[ 'label' ]         = isset( $field[ 'label' ] ) ? $field[ 'label' ] : '';

		$field_id = 'id="' . esc_attr( $field[ 'id' ] ) . '"';

		if ( get_post_meta( $thepostid, $field[ 'id' ], true ) ) {
			$field[ 'value' ] = get_post_meta( $thepostid, $field[ 'id' ], true );
		}

		echo '<p class="form-field ' . esc_attr( $field[ 'wrapper_class' ] ) . '"><label><span>' . wp_kses_post( $field[ 'label' ] ) . '</span><select class="' . esc_attr( $field[ 'class' ] ) . '" name="' . esc_attr( $field[ 'name' ] ) . '" ' . $field_id . '>';

		foreach ( $field[ 'options' ] as $key => $value ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( esc_attr( $field[ 'value' ] ), esc_attr( $key ), false ) . '>' . esc_html( $value ) . '</option>';
		}

		echo '</select></label>';

		if ( ! empty( $field[ 'description' ] ) ) {
			echo '<span class="description">' . wp_kses_post( $field[ 'description' ] ) . '</span>';
		}

		echo '</p>';
	}

	/**
	 * Output a media input box.
	 */
	public static function media_input() {
		global $thepostid, $post;

		$thepostid                = empty( $thepostid ) ? $post->ID : $thepostid;

		echo '<div class="form-field">';

		echo '<div id="page-carousel-images-container">';

		echo '<ul class="carousel-images">';
		$page_carousel_images = get_post_meta( $thepostid, 'mh_page_carousel_images', true );
		$attachments = array_filter( explode( ',', $page_carousel_images ) );

		if ( ! empty( $attachments ) ) {
			foreach ( $attachments as $attachment_id ) {
				echo '<li class="image" data-attachment_id="' . esc_attr( $attachment_id ) . '">
					' . wp_get_attachment_image( $attachment_id, 'thumbnail' ) . '
					<a href="#" class="delete" title="' . esc_attr__( 'Delete image', 'morrison-hotel-toolkit' ) . '">' . esc_html__( 'Delete', 'morrison-hotel-toolkit' ) . '</a>
				</li>';
			}
		}
		echo '</ul>';

		echo '<input type="hidden" id="page-carousel-images" name="mh_page_carousel_images" value="' . esc_attr( $page_carousel_images ) . '" />';

		echo '</div>';

		echo '<p class="add-page-carousel-images-wrap hide-if-no-js">';

		echo '<a href="#" class="button button-primary" id="add-page-carousel-images" data-choose="' . esc_attr__( 'Add images to Page Carousel', 'morrison-hotel-toolkit' ) . '" data-update="' . esc_attr__( 'Add to carousel', 'morrison-hotel-toolkit' ) . '" data-delete="' . esc_attr__( 'Delete image', 'morrison-hotel-toolkit' ) . '" data-text="' . esc_attr__( 'Delete', 'morrison-hotel-toolkit' ) . '">' . esc_html__( 'Add page carousel images', 'morrison-hotel-toolkit' ) . '</a>';

		echo '</p>';

		echo '</div>';
	}
}

endif;
