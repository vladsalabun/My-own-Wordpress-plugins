<?php
/**
 * Widget Functions.
 *
 * @author   Lollum
 * @category Core
 * @package  Morrison_Hotel_Toolkit/Functions
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Include widget classes.
include_once( 'widgets/abstract-widget.php' );
include_once( 'widgets/class-widget-social.php' );
include_once( 'widgets/class-widget-newsletter.php' );

/**
 * Register Widgets.
 */
function morrison_hotel_toolkit_register_widgets() {
	register_widget( 'MH_TKT_Widget_Social' );
	register_widget( 'MH_TKT_Widget_Newsletter' );
}
add_action( 'widgets_init', 'morrison_hotel_toolkit_register_widgets' );
