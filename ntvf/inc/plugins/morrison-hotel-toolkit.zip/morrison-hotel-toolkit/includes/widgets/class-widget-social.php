<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Icons Widget.
 *
 * Displays social icons.
 *
 * @author   Lollum
 * @category Widgets
 * @package  Morrison_Hotel_Toolkit/Widgets
 * @version  1.0.1
 * @extends  MH_TKT_Widget
 */

class MH_TKT_Widget_Social extends MH_TKT_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->widget_cssclass    = 'widget-morrison-hotel morrison-hotel-widget-social';
		$this->widget_description = esc_html__( 'Displays social icons.', 'morrison-hotel-toolkit' );
		$this->widget_id          = 'morrison-hotel-widget-social';
		$this->widget_name        = esc_html__( 'Morrison Hotel - Social Icons', 'morrison-hotel-toolkit' );
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Title', 'morrison-hotel-toolkit' )
			),
			'target'  => array(
				'type'  => 'checkbox',
				'std'   => '',
				'label' => esc_html__( 'Open social links in a new window/tab?', 'morrison-hotel-toolkit' )
			),
			'facebook'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Facebook', 'morrison-hotel-toolkit' )
			),
			'twitter'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Twitter', 'morrison-hotel-toolkit' )
			),
			'dribbble'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Dribbble', 'morrison-hotel-toolkit' )
			),
			'linkedin'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Linkedin', 'morrison-hotel-toolkit' )
			),
			'flickr'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Flickr', 'morrison-hotel-toolkit' )
			),
			'tumblr'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Tumblr', 'morrison-hotel-toolkit' )
			),
			'vimeo'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Vimeo', 'morrison-hotel-toolkit' )
			),
			'youtube'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Youtube', 'morrison-hotel-toolkit' )
			),
			'instagram'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Instagram', 'morrison-hotel-toolkit' )
			),
			'google'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Google Plus', 'morrison-hotel-toolkit' )
			),
			'foursquare'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Foursquare', 'morrison-hotel-toolkit' )
			),
			'github'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Github', 'morrison-hotel-toolkit' )
			),
			'pinterest'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Pinterest', 'morrison-hotel-toolkit' )
			),
			'stackoverflow'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Stackoverflow', 'morrison-hotel-toolkit' )
			),
			'deviantart'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Deviantart', 'morrison-hotel-toolkit' )
			),
			'behance'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Behance', 'morrison-hotel-toolkit' )
			),
			'delicious'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Delicious', 'morrison-hotel-toolkit' )
			),
			'soundcloud'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Soundcloud', 'morrison-hotel-toolkit' )
			),
			'spotify'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Spotify', 'morrison-hotel-toolkit' )
			),
			'stumbleupon'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Stumbleupon', 'morrison-hotel-toolkit' )
			),
			'reddit'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Reddit', 'morrison-hotel-toolkit' )
			),
			'vine'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Vine', 'morrison-hotel-toolkit' )
			),
			'digg'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Digg', 'morrison-hotel-toolkit' )
			),
			'vk'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Vk', 'morrison-hotel-toolkit' )
			),
			'yelp'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Yelp', 'morrison-hotel-toolkit' )
			),
			'medium'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Medium', 'morrison-hotel-toolkit' )
			),
			'slack'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Slack', 'morrison-hotel-toolkit' )
			),
			'tripadvisor'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Tripadvisor', 'morrison-hotel-toolkit' )
			),
			'rss'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'RSS', 'morrison-hotel-toolkit' )
			),
		);

		parent::__construct();
	}

	/**
	 * widget function.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		$target        = ! empty( $instance[ 'target' ] ) ? 'target="_blank"' : '';
		$facebook      = ! empty( $instance[ 'facebook' ] ) ? $instance[ 'facebook' ] : false;
		$twitter       = ! empty( $instance[ 'twitter' ] ) ? $instance[ 'twitter' ] : false;
		$dribbble      = ! empty( $instance[ 'dribbble' ] ) ? $instance[ 'dribbble' ] : false;
		$linkedin      = ! empty( $instance[ 'linkedin' ] ) ? $instance[ 'linkedin' ] : false;
		$flickr        = ! empty( $instance[ 'flickr' ] ) ? $instance[ 'flickr' ] : false;
		$tumblr        = ! empty( $instance[ 'tumblr' ] ) ? $instance[ 'tumblr' ] : false;
		$vimeo         = ! empty( $instance[ 'vimeo' ] ) ? $instance[ 'vimeo' ] : false;
		$youtube       = ! empty( $instance[ 'youtube' ] ) ? $instance[ 'youtube' ] : false;
		$instagram     = ! empty( $instance[ 'instagram' ] ) ? $instance[ 'instagram' ] : false;
		$google        = ! empty( $instance[ 'google' ] ) ? $instance[ 'google' ] : false;
		$foursquare    = ! empty( $instance[ 'foursquare' ] ) ? $instance[ 'foursquare' ] : false;
		$github        = ! empty( $instance[ 'github' ] ) ? $instance[ 'github' ] : false;
		$pinterest     = ! empty( $instance[ 'pinterest' ] ) ? $instance[ 'pinterest' ] : false;
		$stackoverflow = ! empty( $instance[ 'stackoverflow' ] ) ? $instance[ 'stackoverflow' ] : false;
		$deviantart    = ! empty( $instance[ 'deviantart' ] ) ? $instance[ 'deviantart' ] : false;
		$behance       = ! empty( $instance[ 'behance' ] ) ? $instance[ 'behance' ] : false;
		$delicious     = ! empty( $instance[ 'delicious' ] ) ? $instance[ 'delicious' ] : false;
		$soundcloud    = ! empty( $instance[ 'soundcloud' ] ) ? $instance[ 'soundcloud' ] : false;
		$spotify       = ! empty( $instance[ 'spotify' ] ) ? $instance[ 'spotify' ] : false;
		$stumbleupon   = ! empty( $instance[ 'stumbleupon' ] ) ? $instance[ 'stumbleupon' ] : false;
		$reddit        = ! empty( $instance[ 'reddit' ] ) ? $instance[ 'reddit' ] : false;
		$vine          = ! empty( $instance[ 'vine' ] ) ? $instance[ 'vine' ] : false;
		$digg          = ! empty( $instance[ 'digg' ] ) ? $instance[ 'digg' ] : false;
		$vk            = ! empty( $instance[ 'vk' ] ) ? $instance[ 'vk' ] : false;
		$yelp          = ! empty( $instance[ 'yelp' ] ) ? $instance[ 'yelp' ] : false;
		$medium        = ! empty( $instance[ 'medium' ] ) ? $instance[ 'medium' ] : false;
		$slack         = ! empty( $instance[ 'slack' ] ) ? $instance[ 'slack' ] : false;
		$tripadvisor   = ! empty( $instance[ 'tripadvisor' ] ) ? $instance[ 'tripadvisor' ] : false;
		$rss           = ! empty( $instance[ 'rss' ] ) ? $instance[ 'rss' ] : false;

		$this->widget_start( $args, $instance );
		?>

		<ul class="site-follow">
			<?php if ( $facebook ) : ?>
				<li><a href="<?php echo esc_url( $facebook ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-facebook"></i></a></li>
			<?php endif; ?>
			<?php if ( $twitter ) : ?>
				<li><a href="<?php echo esc_url( $twitter ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-twitter"></i></a></li>
			<?php endif; ?>
			<?php if ( $dribbble ) : ?>
				<li><a href="<?php echo esc_url( $dribbble ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-dribbble"></i></a></li>
			<?php endif; ?>
			<?php if ( $linkedin ) : ?>
				<li><a href="<?php echo esc_url( $linkedin ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-linkedin"></i></a></li>
			<?php endif; ?>
			<?php if ( $flickr ) : ?>
				<li><a href="<?php echo esc_url( $flickr ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-flickr"></i></a></li>
			<?php endif; ?>
			<?php if ( $tumblr ) : ?>
				<li><a href="<?php echo esc_url( $tumblr ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-tumblr"></i></a></li>
			<?php endif; ?>
			<?php if ( $vimeo ) : ?>
				<li><a href="<?php echo esc_url( $vimeo ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-vimeo-square"></i></a></li>
			<?php endif; ?>
			<?php if ( $youtube ) : ?>
				<li><a href="<?php echo esc_url( $youtube ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-youtube"></i></a></li>
			<?php endif; ?>
			<?php if ( $instagram ) : ?>
				<li><a href="<?php echo esc_url( $instagram ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-instagram"></i></a></li>
			<?php endif; ?>
			<?php if ( $google ) : ?>
				<li><a href="<?php echo esc_url( $google ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-google-plus"></i></a></li>
			<?php endif; ?>
			<?php if ( $foursquare ) : ?>
				<li><a href="<?php echo esc_url( $foursquare ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-foursquare"></i></a></li>
			<?php endif; ?>
			<?php if ( $github ) : ?>
				<li><a href="<?php echo esc_url( $github ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-github"></i></a></li>
			<?php endif; ?>
			<?php if ( $pinterest ) : ?>
				<li><a href="<?php echo esc_url( $pinterest ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-pinterest"></i></a></li>
			<?php endif; ?>
			<?php if ( $stackoverflow ) : ?>
				<li><a href="<?php echo esc_url( $stackoverflow ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-stack-overflow"></i></a></li>
			<?php endif; ?>
			<?php if ( $deviantart ) : ?>
				<li><a href="<?php echo esc_url( $deviantart ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-deviantart"></i></a></li>
			<?php endif; ?>
			<?php if ( $behance ) : ?>
				<li><a href="<?php echo esc_url( $behance ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-behance"></i></a></li>
			<?php endif; ?>
			<?php if ( $soundcloud ) : ?>
				<li><a href="<?php echo esc_url( $soundcloud ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-soundcloud"></i></a></li>
			<?php endif; ?>
			<?php if ( $spotify ) : ?>
				<li><a href="<?php echo esc_url( $spotify ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-spotify"></i></a></li>
			<?php endif; ?>
			<?php if ( $stumbleupon ) : ?>
				<li><a href="<?php echo esc_url( $stumbleupon ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-stumbleupon"></i></a></li>
			<?php endif; ?>
			<?php if ( $reddit ) : ?>
				<li><a href="<?php echo esc_url( $reddit ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-reddit"></i></a></li>
			<?php endif; ?>
			<?php if ( $vine ) : ?>
				<li><a href="<?php echo esc_url( $vine ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-vine"></i></a></li>
			<?php endif; ?>
			<?php if ( $digg ) : ?>
				<li><a href="<?php echo esc_url( $digg ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-digg"></i></a></li>
			<?php endif; ?>
			<?php if ( $vk ) : ?>
				<li><a href="<?php echo esc_url( $vk ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-vk"></i></a></li>
			<?php endif; ?>
			<?php if ( $yelp ) : ?>
				<li><a href="<?php echo esc_url( $yelp ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-yelp"></i></a></li>
			<?php endif; ?>
			<?php if ( $medium ) : ?>
				<li><a href="<?php echo esc_url( $medium ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-medium"></i></a></li>
			<?php endif; ?>
			<?php if ( $slack ) : ?>
				<li><a href="<?php echo esc_url( $slack ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-slack"></i></a></li>
			<?php endif; ?>
			<?php if ( $tripadvisor ) : ?>
				<li><a href="<?php echo esc_url( $tripadvisor ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-tripadvisor"></i></a></li>
			<?php endif; ?>
			<?php if ( $rss ) : ?>
				<li><a href="<?php echo esc_url( $rss ); ?>" <?php echo esc_attr( $target ); ?>><i class="fa fa-rss"></i></a></li>
			<?php endif; ?>
		</ul>

		<?php
		$this->widget_end( $args );
	}
}
