<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Newsletter Widget.
 *
 * Displays a MailChimp form.
 *
 * @author   Lollum
 * @category Widgets
 * @package  Morrison_Hotel_Toolkit/Widgets
 * @version  1.0.0
 * @extends  MH_TKT_Widget
 */

class MH_TKT_Widget_Newsletter extends MH_TKT_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->widget_cssclass    = 'widget-morrison-hotel morrison-hotel-widget-newsletter';
		$this->widget_description = esc_html__( 'Displays a newsletter form. You need a Mailchimp account to use it.', 'morrison-hotel-toolkit' );
		$this->widget_id          = 'morrison-hotel-widget-newsletter';
		$this->widget_name        = esc_html__( 'Morrison Hotel - Newsletter', 'morrison-hotel-toolkit' );
		$this->settings           = array(
			'title'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Title', 'morrison-hotel-toolkit' )
			),
			'description'  => array(
				'type'  => 'textarea',
				'std'   => '',
				'label' => esc_html__( 'Description', 'morrison-hotel-toolkit' )
			),
			'list'  => array(
				'type'  => 'text',
				'std'   => '',
				'label' => esc_html__( 'Enter your MailChimp List ID here.', 'morrison-hotel-toolkit' ) . ' <a href="http://kb.mailchimp.com/article/how-can-i-find-my-list-id" title="How can I find my List ID?">How can I find my List ID?</a>'
			),
			'name'  => array(
				'type'  => 'checkbox',
				'std'   => '',
				'label' => esc_html__( 'Display Name Fields?', 'morrison-hotel-toolkit' ),
			),
			'confirm'  => array(
				'type'        => 'select',
				'std'         => '',
				'label'       => esc_html__( 'Display Name Fields?', 'morrison-hotel-toolkit' ),
				'options'     => array( 'welcome-email', 'opt-in', 'nothing' ),
				'description' => esc_html__( 'You can send a "welcome" email after the subscribtion or enable the "double opt-in" option. In this case when your subscriber checks their inbox, they will see an email with a link to confirm their subscription.', 'morrison-hotel-toolkit' ),
			),
			'btn_text'  => array(
				'type'  => 'text',
				'std'   => esc_html__( 'Subscribe', 'morrison-hotel-toolkit' ),
				'label' => esc_html__( 'Button Text', 'morrison-hotel-toolkit' )
			),
		);

		parent::__construct();
	}

	/**
	 * widget function.
	 *
	 * @see WP_Widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		$list        = $instance[ 'list' ];
		$description = $instance[ 'description' ];
		$name        = ! empty( $instance[ 'name' ] ) ? $instance[ 'name' ] : false;
		$confirm     = $instance[ 'confirm' ];
		$btn_text    = $instance[ 'btn_text' ];

		$this->widget_start( $args, $instance );
		?>

		<div class="morrison-hotel-newsletter">
			<form class="morrison-hotel-newsletter-form" name="morrison-hotel-newsletter-form" method="post" data-name="<?php echo $name ? 'yes' : 'no'; ?>" data-confirm="<?php echo esc_attr( $confirm ); ?>">

				<?php if ( $description ) : ?>
					<p class="morrison-hotel-newsletter-description">
						<?php echo $description; ?>
					</p>
				<?php endif; ?>

				<?php if ( $name ) : ?>
					<p class="morrison-hotel-newsletter-field morrison-hotel-newsletter-field-first">
						<label><?php esc_html_e( 'First Name', 'morrison-hotel-toolkit' ); ?></label>
						<input type="text" placeholder="<?php esc_attr_e( 'First Name', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-first-name">
					</p>

					<p class="morrison-hotel-newsletter-field morrison-hotel-newsletter-field-last">
						<label><?php esc_html_e( 'Last Name', 'morrison-hotel-toolkit' ); ?></label>
						<input type="text" placeholder="<?php esc_attr_e( 'Last Name', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-last-name">
					</p>
				<?php endif; ?>

				<p class="morrison-hotel-newsletter-field">
					<label><?php esc_html_e( 'Email Address', 'morrison-hotel-toolkit' ); ?></label>
					<input type="text" placeholder="<?php esc_attr_e( 'Email Address', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-email">
				</p>

				<input type="hidden" class="morrison-hotel-newsletter-list-id" value="<?php echo esc_attr( $list ); ?>" />

				<input type="submit" value="<?php echo esc_attr( $btn_text ); ?>" data-wait-text="<?php esc_attr_e( 'Please wait...', 'morrison-hotel-toolkit' ); ?>" class="morrison-hotel-newsletter-button">

			</form>

			<div class="morrison-hotel-newsletter-response"></div>

		</div>

		<?php
		wp_enqueue_script( 'mh_tkt-mailchimp' );

		$this->widget_end( $args );
	}
}
