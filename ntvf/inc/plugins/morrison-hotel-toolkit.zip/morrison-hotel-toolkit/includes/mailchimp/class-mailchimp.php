<?php
/**
 * Morrison_Hotel_Toolkit Mailchimp Class.
 *
 * @author   Lollum
 * @category Classes
 * @package  Morrison_Hotel_Toolkit/Classes
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'MH_TKT_Mailchimp' ) ) :

/**
 * MH_TKT_Mailchimp Class
 */
class MH_TKT_Mailchimp {

	/**
	 * Initialize the class and set its properties.
	 *
	 * @access public
	 * @return MH_TKT_Mailchimp
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'mailchimp_scripts' ) );
		add_action( 'wp_ajax_morrison_hotel_mailchimp_form', array( $this, 'mailchimp_form' ), 10, 2 );
		add_action( 'wp_ajax_nopriv_morrison_hotel_mailchimp_form', array( $this, 'mailchimp_form' ), 10, 2 );
	}

	/**
	 * Mailchimp scripts.
	 *
	 * @access public
	 */
	public function mailchimp_scripts() {
		wp_register_script( 'mh_tkt-mailchimp', MH_TKT_PLUGIN_URL . 'assets/js/morrison-hotel-toolkit-mailchimp.min.js', array( 'jquery' ), MH_TKT_VERSION, true );
		wp_localize_script( 'mh_tkt-mailchimp', 'morrison_hotel_process_form_vars',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'morrison_hotel-mailchimp-form-nonce' )
			)
		);
	}

	/**
	 * Process the Mailchimp form.
	 *
	 * @access public
	 * @return string
	 */
	public function mailchimp_form() {
		// $options = get_option( 'lollum_toolkit_options' );
		// $mailchimp_api = $options[ 'mailchimp_key' ];
		$mailchimp_api = get_theme_mod( 'morrison_hotel_opt_mailchimp_api' );

		if ( ! $mailchimp_api ) {

			echo '<div class="morrison-hotel-newsletter-message morrison-hotel-newsletter-error">' . apply_filters( 'morrison_hotel_newsletter_api_error_filter', esc_html__( 'Please insert a correct MailChimp API key in WP > Customize > Mailchimp.', 'morrison-hotel' ) ) . '</div>';

		} elseif ( empty( $_POST[ 'morrison_hotel_m_list_id' ] ) ) {

			echo '<div class="morrison-hotel-newsletter-message morrison-hotel-newsletter-error">' . apply_filters( 'morrison_hotel_newsletter_id_error_filter', esc_html__( 'Please insert the ID of your MailChimp list.', 'morrison-hotel' ) ) . '</div>';

		} else {

			$display_name = false;
			$welcome      = false;
			$opt_in       = false;

			if ( isset( $_POST[ 'morrison_hotel_m_display_name' ] ) && $_POST[ 'morrison_hotel_m_display_name' ] == 'yes' ) {
				$display_name = true;
			}

			if ( isset( $_POST[ 'morrison_hotel_m_confirm' ] ) &&  $_POST[ 'morrison_hotel_m_confirm' ] != 'nothing' ) {
				$welcome = true;
			}

			if ( isset( $_POST[ 'morrison_hotel_m_confirm' ] ) &&  $_POST[ 'morrison_hotel_m_confirm' ] == 'opt-in' ) {
				$opt_in = true;
			}

			if ( $display_name && ( empty( $_POST[ 'morrison_hotel_m_first_name' ] ) || empty( $_POST[ 'morrison_hotel_m_last_name' ] ) ) ) {
				echo '<div class="morrison-hotel-newsletter-message morrison-hotel-newsletter-error">' . apply_filters( 'morrison_hotel_newsletter_names_error_filter', esc_html__( 'Please fill the "First Name" and the "Last Name" fields', 'morrison-hotel' ) ) . '</div>';
			}

			if ( empty( $_POST[ 'morrison_hotel_m_email' ] ) || ! is_email( $_POST[ 'morrison_hotel_m_email' ] ) ) {
				echo '<div class="morrison-hotel-newsletter-message morrison-hotel-newsletter-error">' . apply_filters( 'morrison_hotel_newsletter_email_error_filter', esc_html__( 'Please type a correct email address.', 'morrison-hotel' ) ) . '</div>';
			}

			if ( wp_verify_nonce( $_POST[ 'morrison_hotel_m_nonce' ], 'morrison_hotel-mailchimp-form-nonce' ) && ( $display_name && ! empty( $_POST[ 'morrison_hotel_m_first_name' ] ) && ! empty( $_POST[ 'morrison_hotel_m_last_name' ] ) && ! empty( $_POST[ 'morrison_hotel_m_email' ] ) && is_email( $_POST[ 'morrison_hotel_m_email' ] ) ) || ( ! $display_name && ! empty( $_POST[ 'morrison_hotel_m_email' ] ) && is_email( $_POST[ 'morrison_hotel_m_email' ] ) ) ) {

				$MailChimp = new Drewm_MailChimp( $mailchimp_api );
				$result    = $MailChimp->call( 'lists/subscribe', array(
					'id'                => sanitize_text_field( $_POST[ 'morrison_hotel_m_list_id' ] ),
					'email'             => array( 'email' => sanitize_email( $_POST[ 'morrison_hotel_m_email' ] ) ),
					'merge_vars'        => ( $display_name ? array( 'FNAME' => sanitize_text_field( $_POST[ 'morrison_hotel_m_first_name' ] ), 'LNAME' => sanitize_text_field( $_POST[ 'morrison_hotel_m_last_name' ] ) ) : array() ),
					'double_optin'      => $opt_in,
					'update_existing'   => true,
					'replace_interests' => false,
					'send_welcome'      => $welcome,
				) );

				echo '<div class="morrison-hotel-newsletter-message morrison-hotel-newsletter-success">' . apply_filters( 'morrison_hotel_newsletter_success_filter', esc_html__( 'Thank you for subscribing!', 'morrison-hotel' ) ) . '</div>';
			}

		}

		die();
	}
}

endif;

return new MH_TKT_Mailchimp();
