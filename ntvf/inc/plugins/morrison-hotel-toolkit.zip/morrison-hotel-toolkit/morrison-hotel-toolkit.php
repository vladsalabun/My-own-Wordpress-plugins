<?php

/**
 * Plugin Name:       Morrison Hotel Toolkit
 * Plugin URI:        http://lollum.com/
 * Description:       Extra functionality for the Morrison Hotel theme.
 * Version:           1.0.3
 * Author:            Lollum
 * Author URI:        http://lollum.com/
 * Requires at least: 4.1
 * Tested up to:      4.5.3
 * License:           GPLv3
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       morrison-hotel-toolkit
 * Domain Path:       languages
 *
 * @package  Morrison_Hotel_Toolkit
 * @category Core
 * @author   Lollum
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'Morrison_Hotel_Toolkit' ) ) :

/**
 * Main Morrison_Hotel_Toolkit Class
 */
final class Morrison_Hotel_Toolkit {

	/**
	 * @var string
	 */
	public $version = '1.0.3';

	/**
	 * @var Morrison_Hotel_Toolkit The single instance of the class
	 */
	private static $_instance = null;

	/**
	 * Main Morrison_Hotel_Toolkit Instance
	 *
	 * Insures that only one instance of Morrison_Hotel_Toolkit exists in memory at any one time.
	 *
	 * @static
	 * @see MH_TKT()
	 * @return Morrison_Hotel_Toolkit - Main instance
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Cloning is forbidden.
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'morrison-hotel-toolkit' ), '1.0.0' );
	}

	/**
	 * Unserializing instances of this class is forbidden.
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'morrison-hotel-toolkit' ), '1.0.0' );
	}

	/**
	 * Morrison_Hotel_Toolkit Constructor.
	 */
	public function __construct() {
		$this->setup_constants();
		$this->includes();
		$this->init_hooks();

		do_action( 'morrison_hotel_toolkit_loaded' );
	}

	/**
	 * Hook into actions and filters
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'init' ), 0 );

		if ( $this->is_request( 'frontend' ) ) {
			add_action( 'init', array( 'MH_TKT_Shortcodes', 'init' ) );
		}
	}

	/**
	 * Setup plugin constants
	 *
	 * @access private
	 * @return void
	 */
	private function setup_constants() {
		$upload_dir = wp_upload_dir();

		// Plugin version
		if ( ! defined( 'MH_TKT_VERSION' ) ) {
			define( 'MH_TKT_VERSION', $this->version );
		}

		// Plugin Folder Path
		if ( ! defined( 'MH_TKT_PLUGIN_DIR' ) ) {
			define( 'MH_TKT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
		}

		// Plugin Folder URL
		if ( ! defined( 'MH_TKT_PLUGIN_URL' ) ) {
			define( 'MH_TKT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
		}

		// Plugin Root File
		if ( ! defined( 'MH_TKT_PLUGIN_FILE' ) ) {
			define( 'MH_TKT_PLUGIN_FILE', __FILE__ );
		}
	}

	/**
	 * What type of request is this?
	 * string $type ajax, frontend or admin
	 * @return bool
	 */
	private function is_request( $type ) {
		switch ( $type ) {
			case 'admin' :
				return is_admin();
			case 'ajax' :
				return defined( 'DOING_AJAX' );
			case 'frontend' :
				return ( ! is_admin() || defined( 'DOING_AJAX' ) );
		}
	}

	/**
	 * Include required files used in admin and on the frontend.
	 *
	 * @access private
	 * @return void
	 */
	private function includes() {
		include_once MH_TKT_PLUGIN_DIR . 'includes/widget-functions.php';

		if ( is_admin() ) {
			include_once MH_TKT_PLUGIN_DIR . 'includes/admin/class-metaboxes.php';
			include_once MH_TKT_PLUGIN_DIR . 'includes/admin/class-admin.php';
		}

		if ( $this->is_request( 'frontend' ) ) {
			$this->frontend_includes();
		}
	}

	/**
	 * Include required frontend files.
	 */
	public function frontend_includes() {
		include_once MH_TKT_PLUGIN_DIR . 'includes/mailchimp/MailChimp.php';
		include_once MH_TKT_PLUGIN_DIR . 'includes/mailchimp/class-mailchimp.php';
		include_once MH_TKT_PLUGIN_DIR . 'includes/class-shortcodes.php';
		include_once MH_TKT_PLUGIN_DIR . 'includes/core-functions.php';
	}

	/**
	 * Init Morrison_Hotel_Toolkit when WordPress initialises.
	 *
	 * @access public
	 * @return void
	 */
	public function init() {
		// Before init action
		do_action( 'before_morrison_hotel_toolkit_init' );

		// Set up localisation
		$this->load_textdomain();

		// Init action
		do_action( 'morrison_hotel_toolkit_init' );
	}

	/**
	 * Loads the plugin language files
	 *
	 * @access public
	 * @return void
	 */
	public function load_textdomain() {
		// Set filter for plugin's languages directory
		$morrison_hotel_toolkit_lang_dir = dirname( plugin_basename( MH_TKT_PLUGIN_FILE ) ) . '/languages/';

		// Traditional WordPress plugin locale filter
		$locale = apply_filters( 'plugin_locale', get_locale(), 'morrison-hotel-toolkit' );
		$mofile = sprintf( '%1$s-%2$s.mo', 'morrison-hotel-toolkit', $locale );

		// Setup paths to current locale file
		$mofile_local  = $morrison_hotel_toolkit_lang_dir . $mofile;
		$mofile_global = WP_LANG_DIR . '/morrison-hotel-toolkit/' . $mofile;

		if ( file_exists( $mofile_global ) ) {
			// Look in global /wp-content/languages/morrison-hotel-toolkit folder
			load_textdomain( 'morrison-hotel-toolkit', $mofile_global );
		} elseif ( file_exists( $mofile_local ) ) {
			// Look in local /wp-content/plugins/morrison-hotel-toolkit/languages/ folder
			load_textdomain( 'morrison-hotel-toolkit', $mofile_local );
		} else {
			// Load the default language files
			load_plugin_textdomain( 'morrison-hotel-toolkit', false, $morrison_hotel_toolkit_lang_dir );
		}
	}

	/**
	 * Get the plugin url.
	 * @return string
	 */
	public function plugin_url() {
		return untrailingslashit( plugins_url( '/', __FILE__ ) );
	}

	/**
	 * Get the plugin path.
	 * @return string
	 */
	public function plugin_path() {
		return untrailingslashit( plugin_dir_path( __FILE__ ) );
	}

	/**
	 * Get Ajax URL.
	 * @return string
	 */
	public function ajax_url() {
		return admin_url( 'admin-ajax.php', 'relative' );
	}
}

endif;

/**
 * Returns the main instance of MH_TKT to prevent the need to use globals.
 *
 * @return Morrison_Hotel_Toolkit
 */
function MH_TKT() {
	return Morrison_Hotel_Toolkit::instance();
}

// Get MH_TKT Running
MH_TKT();
