(function() {
	'use strict';
	/* global tinymce, wp */
	tinymce.PluginManager.add('morrison_hotel_toolkit_shortcodes_btn', function(editor) {
		editor.addButton('morrison_hotel_toolkit_shortcodes_btn', {
			text: 'Morrison Hotel Shortcodes',
			type: 'menubutton',
			tooltip: 'Add Shortcode',
			both: true,
			menu: [
				{
					text: 'Wrap',
					icon: 'icon dashicons-align-center',
					value: '[morrison_hotel_wrap]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_wrap]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Title',
					icon: 'icon dashicons-editor-textcolor',
					value: '[morrison_hotel_title alignment="center" border="yes"]Your title here[/morrison_hotel_title]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Separator',
					icon: 'icon dashicons-editor-insertmore',
					value: '[morrison_hotel_separator]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Big',
					icon: 'icon dashicons-editor-bold',
					value: '[morrison_hotel_big alignment="center"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_big]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Columns',
					icon: 'icon dashicons-text',
					onclick: function() {
						morrison_hotel_toolkit_add_columns(editor);
					},
				},
				{
					text: 'Services',
					icon: 'icon dashicons-awards',
					onclick: function() {
						morrison_hotel_toolkit_add_services(editor);
					},
				},
				{
					text: 'Toggle',
					icon: 'icon dashicons-sort',
					onclick: function() {
						morrison_hotel_toolkit_add_toggle(editor);
					},
				},
				{
					text: 'Newsletter',
					icon: 'icon dashicons-email',
					onclick: function() {
						morrison_hotel_toolkit_add_newsletter(editor);
					},
				},
				{
					text: 'Gallery',
					icon: 'icon dashicons-format-gallery',
					onclick: function() {
						morrison_hotel_toolkit_gallery_modal(editor);
					},
				},
				{
					text: 'Page-Boxes',
					icon: 'icon dashicons-grid-view',
					value: '[morrison_hotel_page_boxes ids=""]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Menu',
					icon: 'icon dashicons-editor-ul',
					value: '[morrison_hotel_menu title="Section title"]<br><br>#Dish name<br>*Dish description<br>=$0.00<br><br>#Dish name<br>*Dish description<br>=$0.00<br><br>[/morrison_hotel_menu]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Testimonials',
					icon: 'icon dashicons-format-quote',
					value: '[morrison_hotel_testimonials title="Testimonials title here..."]<br><br>#Testimonial text<br>*Testimonial author<br>=Tagline<br><br>[/morrison_hotel_testimonials]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Button',
					icon: 'icon dashicons-plus-alt',
					value: '[morrison_hotel_button link="http://example.com/" text="Button" target="_self"]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Map',
					icon: 'icon dashicons-location-alt',
					value: '[morrison_hotel_map latitude="" longitude="" zoom="15" size="normal" marker="yes" hue=""]<br><br><br>',
					onclick: function(e) {
						e.stopPropagation();
						editor.insertContent(this.value());
					},
				},
				{
					text: 'Rooms',
					icon: 'icon dashicons-minus',
					menu: [
						{
							text: 'Recent Rooms',
							value: '[hotelier_recent_rooms per_page="6" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
						{
							text: 'Rooms by ID',
							value: '[hotelier_rooms ids="" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
						{
							text: 'Rooms by Category',
							value: '[hotelier_room_type category="" per_page="3" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
					]
				},
				{
					text: 'Posts',
					icon: 'icon dashicons-format-aside',
					menu: [
						{
							text: 'Recent Posts',
							value: '[morrison_hotel_recent_posts per_page="3" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
						{
							text: 'Posts by ID',
							value: '[morrison_hotel_posts ids="" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
						{
							text: 'Posts by Category',
							value: '[morrison_hotel_post_category category="" per_page="3" columns="3"]<br><br><br>',
							onclick: function(e) {
								e.stopPropagation();
								editor.insertContent(this.value());
							},
						},
					]
				},
			]
		});
	});
})();

function morrison_hotel_toolkit_add_columns(editor) {
	editor.windowManager.open({
		title: 'Insert Columns',
		width: 300,
		height: 60,
		body: [
			{
				type: 'listbox',
				name: 'columns',
				label: 'Columns',
				'values': [
					{ text: '1/2 | 1/2', value: '2' },
					{ text: '1/3 | 1/3 | 1/3', value:'3' },
					{ text: '1/3 | 2/3', value:'1-3' },
					{ text: '2/3 | 1/3', value:'2-3' },
					{ text: '1/4 | 1/4 | 1/4 | 1/4', value:'4' },
					{ text: '1/4 | 1/4 | 2/4', value:'1-1-2' },
					{ text: '1/4 | 2/4 | 1/4', value:'1-2-1' },
					{ text: '2/4 | 1/4 | 1/4', value:'2-1-1' },
				]
			},
		],
		onsubmit: function(e) {
			var cols = e.data.columns;
			var columns_content = '';

			if (cols === '2') {
				columns_content = '[morrison_hotel_column column="one-half"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-half" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '3') {
				columns_content = '[morrison_hotel_column column="one-third"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-third"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-third" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '1-3') {
				columns_content = '[morrison_hotel_column column="one-third"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="two-third" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '2-3') {
				columns_content = '[morrison_hotel_column column="two-third"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-third" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '4') {
				columns_content = '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '1-1-2') {
				columns_content = '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-half" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '1-2-1') {
				columns_content = '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-half"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			} else if (cols === '2-1-1') {
				columns_content = '[morrison_hotel_column column="one-half"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br>';
				columns_content +=  '[morrison_hotel_column column="one-fourth" last="true"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_column]' + '<br><br><br>';
			}

			editor.insertContent(columns_content);
		}
	});
}

function morrison_hotel_toolkit_add_services(editor) {
	editor.windowManager.open({
		title: 'Insert Services',
		width: 300,
		height: 60,
		body: [
			{
				type: 'listbox',
				name: 'columns',
				label: 'Columns',
				'values': [
					{ text: '1/2 | 1/2', value: '2' },
					{ text: '1/3 | 1/3 | 1/3', value:'3' },
					{ text: '1/3 | 2/3', value:'1-3' },
					{ text: '2/3 | 1/3', value:'2-3' },
					{ text: '1/4 | 1/4 | 1/4 | 1/4', value:'4' },
					{ text: '1/4 | 1/4 | 2/4', value:'1-1-2' },
					{ text: '1/4 | 2/4 | 1/4', value:'1-2-1' },
					{ text: '2/4 | 1/4 | 1/4', value:'2-1-1' },
				]
			},
		],
		onsubmit: function(e) {
			var cols = e.data.columns;
			var services_content = '';

			if (cols === '2') {
				services_content = '[morrison_hotel_service column="one-half" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-half" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '3') {
				services_content = '[morrison_hotel_service column="one-third" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-third" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-third" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '1-3') {
				services_content = '[morrison_hotel_service column="one-third" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="two-third" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '2-3') {
				services_content = '[morrison_hotel_service column="two-third" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-third" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '4') {
				services_content = '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '1-1-2') {
				services_content = '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-half" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '1-2-1') {
				services_content = '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-half" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			} else if (cols === '2-1-1') {
				services_content = '[morrison_hotel_service column="one-half" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br>';
				services_content +=  '[morrison_hotel_service column="one-fourth" last="true" title="Service title here..." icon="fa fa-diamond"]<br><br>Lorem ipsum dolor sit amet...<br><br>[/morrison_hotel_service]' + '<br><br><br>';
			}

			editor.insertContent(services_content);
		}
	});
}

function morrison_hotel_toolkit_add_toggle(editor) {
	editor.windowManager.open({
		title: 'Insert Toggle',
		body: [
			{
				type: 'listbox',
				name: 'toggles',
				label: 'Number of toggles',
				'values': [
					{ text: '5', value: '5' },
					{ text: '4', value: '4' },
					{ text: '3', value: '3' },
					{ text: '2', value: '2' },
					{ text: '1', value: '1' }
				]
			}
		],
		onsubmit: function(e) {
			var toggles = e.data.toggles;

			var toggle_content = '[morrison_hotel_toggle]' + '<br><br>';

			for (var i = 0; i < toggles; i++) {
				toggle_content += '[morrison_hotel_toggle_item title="Toggle title here..." state="close"]<br>Lorem ipsum dolor sit amet...<br>[/morrison_hotel_toggle_item]' + '<br>';
			}

			toggle_content += '<br>' + '[/morrison_hotel_toggle]' + '<br><br><br>';

			editor.insertContent(toggle_content);
		}
	});
}

function morrison_hotel_toolkit_add_newsletter(editor) {
	editor.windowManager.open({
		title: 'Insert Newsletter',
		body: [
			{
				type: 'listbox',
				name: 'display_name',
				label: 'Display name fields?',
				'values': [
					{ text: 'yes', value: 'yes' },
					{ text: 'no', value: 'no' }
				]
			},
			{
				type: 'listbox',
				name: 'confirm',
				label: 'Confirm Email',
				'values': [
					{ text: 'welcome-email', value: 'welcome-email' },
					{ text: 'opt-in', value: 'opt-in' },
					{ text: 'nothing', value: 'nothing' }
				]
			},
			{
				type: 'textbox',
				name: 'list_id',
				label: 'MailChimp List ID'
			},
			{
				type: 'textbox',
				name: 'btn_text',
				label: 'Button Text'
			},
		],
		onsubmit: function(e) {
			var newsletter_content = '[morrison_hotel_newsletter display_name="' + e.data.display_name + '" confirm="' + e.data.confirm + '" list_id="' + e.data.list_id + '" btn_text="' + e.data.btn_text + '"]' + '<br><br><br>';

			editor.insertContent(newsletter_content);
		}
	});
}

function morrison_hotel_toolkit_gallery_modal(editor) {
	var file_frame;
	var attachment_ids = '';

	// If the media frame already exists, reopen it.
	if ( file_frame ) {
		file_frame.open();
		return;
	}

	// Create the media frame.
	file_frame = wp.media.frames.file_frame = wp.media({
		title: 'Insert Gallery',
		library : { type : 'image'},
		button: {
			text: 'Insert Gallery',
		},
		multiple: true
	});

	// When the images are selected, run a callback.
	file_frame.on( 'close', function() {

		var selection = file_frame.state().get('selection');

		selection.map( function( attachment ) {

			attachment = attachment.toJSON();

			if ( attachment.id ) {
				attachment_ids = attachment_ids ? attachment_ids + ',' + attachment.id : attachment.id;
			}
		});

		if (attachment_ids) {
			editor.insertContent( '[morrison_hotel_gallery ids="' + attachment_ids + '" speed="4000"]<br><br><br>' );
		}

	});

	// Finally, open the modal
	file_frame.open();
}
